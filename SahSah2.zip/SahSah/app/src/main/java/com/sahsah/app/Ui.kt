package com.sahsah.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Shared look: dark background, rounded cards, clear buttons. */
object Ui {
    const val BG = "#0F1013"
    const val CARD = "#1B1C21"
    const val FIELD = "#26272E"
    const val TEXT = "#EDEDF0"
    const val MUTED = "#9B9BA3"
    const val ACCENT = "#7C5CFF"
    const val GREEN = "#2E9D5B"
    const val RED = "#D64545"
    const val BLUE = "#2F6FDE"
    const val PINK = "#C2407A"
    const val TEAL = "#16877A"
    const val GREY = "#34353C"
    const val ORANGE = "#E58A2B"

    fun color(s: String) = Color.parseColor(s)
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, fill: String, radius: Int = 18) = GradientDrawable().apply {
        setColor(color(fill)); cornerRadius = dp(c, radius).toFloat()
    }

    private fun full() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    /** Sets the screen up and returns the column to add things to. */
    fun screen(a: Activity, title: String, subtitle: String? = null): LinearLayout {
        a.window.statusBarColor = color(BG)
        a.window.navigationBarColor = color(BG)
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 16), dp(a, 20), dp(a, 16), dp(a, 40))
        }
        col.addView(TextView(a).apply {
            text = title; textSize = 30f; setTextColor(color(TEXT)); setTypeface(typeface, Typeface.BOLD)
        })
        if (subtitle != null) col.addView(muted(a, subtitle).apply { setPadding(0, dp(a, 2), 0, dp(a, 8)) })
        a.setContentView(ScrollView(a).apply {
            setBackgroundColor(color(BG)); isFillViewport = true; addView(col)
        })
        return col
    }

    fun card(c: Context, title: String? = null, hint: String? = null): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(c, CARD, 20)
            setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 16))
            layoutParams = full().apply { topMargin = dp(c, 14) }
            if (title != null) addView(TextView(c).apply {
                text = title; textSize = 19f; setTextColor(color(TEXT)); setTypeface(typeface, Typeface.BOLD)
            })
            if (hint != null) addView(muted(c, hint).apply { setPadding(0, dp(c, 4), 0, 0) })
        }

    fun body(c: Context, s: String, size: Float = 16f) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color(TEXT)); setLineSpacing(0f, 1.15f)
    }

    fun muted(c: Context, s: String) = TextView(c).apply {
        text = s; textSize = 14f; setTextColor(color(MUTED)); setLineSpacing(0f, 1.15f)
    }

    fun button(c: Context, s: String, fill: String = GREY, size: Float = 17f, onClick: (View) -> Unit) =
        Button(c).apply {
            text = s; textSize = size; isAllCaps = false; stateListAnimator = null
            setTextColor(Color.WHITE)
            background = rounded(c, fill, 14)
            minHeight = dp(c, 52)
            setOnClickListener(onClick)
            layoutParams = full().apply { topMargin = dp(c, 10) }
        }

    fun paint(b: Button, fill: String) {
        b.background = rounded(b.context, fill, 14)
    }

    /** Small equal-width buttons in one row. */
    fun row(c: Context, vararg buttons: Pair<String, () -> Unit>): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = full().apply { topMargin = dp(c, 10) }
            buttons.forEachIndexed { i, (label, click) ->
                addView(Button(c).apply {
                    text = label; textSize = 14f; isAllCaps = false; stateListAnimator = null
                    setTextColor(Color.WHITE)
                    background = rounded(c, GREY, 12)
                    minHeight = dp(c, 44); minimumHeight = dp(c, 44)
                    setPadding(dp(c, 4), 0, dp(c, 4), 0)
                    setOnClickListener { click() }
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        if (i > 0) marginStart = dp(c, 8)
                    }
                })
            }
        }

    fun field(c: Context, hint: String, value: String = "", multi: Boolean = false) = EditText(c).apply {
        this.hint = hint; setText(value); textSize = 17f
        setTextColor(color(TEXT)); setHintTextColor(color(MUTED))
        background = rounded(c, FIELD, 12)
        setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
        if (multi) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2; gravity = Gravity.TOP or Gravity.START
        }
        layoutParams = full().apply { topMargin = dp(c, 10) }
    }

    fun divider(c: Context) = View(c).apply {
        setBackgroundColor(color(GREY))
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
            topMargin = dp(c, 14); bottomMargin = dp(c, 4)
        }
    }
}
