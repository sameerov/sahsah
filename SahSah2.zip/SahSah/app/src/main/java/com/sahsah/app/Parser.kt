package com.sahsah.app

import android.content.Context
import android.content.Intent

/**
 * Turns what you said or typed into a command. Tolerant of small mishearings:
 * «يلا مات» matches «يلا ماث», «اليوتيوب» matches «يوتيوب», etc.
 *  1) a saved command whose name (or a learned way of hearing it) appears in the sentence
 *  2) built-in phrases: ابحث عن…، شغّل … على يوتيوب، منبّه الساعة…، افتح …
 * Anything else → null.
 */
object Parser {

    // ------------------------------------------------------------ text tools
    fun westernDigits(s: String) = s.map { ch ->
        when (ch) {
            in '٠'..'٩' -> '0' + (ch - '٠')
            in '۰'..'۹' -> '0' + (ch - '۰')
            else -> ch
        }
    }.joinToString("")

    fun norm(s: String): String = westernDigits(s).lowercase()
        .replace(Regex("[ً-ْـ]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .replace(Regex("[،,؟?!.:؛\"'«»()]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    /** Even looser: no spaces, no «ال», similar-sounding letters merged. */
    private fun loose(s: String): String = norm(s).split(" ")
        .joinToString("") { w -> if (w.startsWith("ال") && w.length > 3) w.substring(2) else w }
        .replace('ث', 'ت').replace('ذ', 'د').replace('ظ', 'ض').replace('ط', 'ت')
        .replace('ؤ', 'و').replace('ئ', 'ي').replace("ء", "").replace('ق', 'ا')
        .replace("ph", "f").replace("th", "t")

    private fun tokens(s: String) = s.replace(Regex("[،,؟?!.:؛\"'«»()]"), " ").trim()
        .split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]; d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        return 1.0 - lev(a, b).toDouble() / maxOf(a.length, b.length)
    }

    class Hit(val score: Double, val size: Int, val after: String)

    /** Looks for `phrase` inside `text` word by word. `after` = the words that came after it. */
    fun find(text: String, phrase: String): Hit? {
        val raw = tokens(text)
        val words = raw.map { norm(it) }
        val target = loose(phrase)
        if (target.isEmpty() || words.isEmpty()) return null
        val pLen = norm(phrase).split(" ").size
        val need = when {
            target.length <= 3 -> 1.0
            target.length <= 6 -> 0.8
            else -> 0.74
        }
        var best: Hit? = null
        for (size in maxOf(1, pLen - 1)..(pLen + 1)) {
            for (i in 0..(words.size - size)) {
                val sc = similarity(loose(words.subList(i, i + size).joinToString(" ")), target)
                if (sc >= need && (best == null || sc > best.score)) {
                    best = Hit(sc, target.length, westernDigits(raw.drop(i + size).joinToString(" ")))
                }
            }
        }
        return best
    }

    private fun has(text: String, vararg words: String) = words.any { find(text, it) != null }

    // ------------------------------------------------------------ parsing
    fun parse(c: Context, said: String): Cmd? {
        val t = norm(said)
        if (t.isEmpty()) return null

        // 1. saved commands: best match wins, longer names break ties
        var bestCmd: Cmd? = null
        var bestHit: Hit? = null
        for (cmd in Store.commands(c)) {
            for (phrase in listOf(cmd.name) + cmd.aliases) {
                val h = find(said, phrase) ?: continue
                val better = bestHit == null || h.score > bestHit.score + 0.01 ||
                    (h.score >= bestHit.score - 0.01 && h.size > bestHit.size)
                if (better) { bestHit = h; bestCmd = cmd }
            }
        }
        if (bestCmd != null) {
            val rest = bestHit!!.after.trim()
            return if ((bestCmd.type == CmdType.APP_SEARCH || bestCmd.type == CmdType.CHAT_TYPE) && rest.isNotEmpty())
                bestCmd.copy(c = rest) else bestCmd
        }

        // 2. built-in phrases
        val words = tokens(said)
        val first = norm(words.first())

        if (first in SEARCH_START || has(said, "ابحث عن", "دور على", "دورلي على")) {
            val q = words.dropWhile { norm(it) in SEARCH_START || norm(it) in setOf("عن", "على", "ع", "لي") }
                .joinToString(" ")
            if (q.isNotBlank()) return Cmd(0, said, CmdType.WEB_SEARCH, westernDigits(q))
        }

        if (has(said, "منبه", "منبهه", "alarm")) parseTime(t)?.let { return Cmd(0, said, CmdType.ALARM, it) }

        if (has(said, "يوتيوب", "youtube")) {
            val q = words.filter { w -> YT_STOP.none { similarity(loose(w), loose(it)) >= 0.8 } }.joinToString(" ")
            if (q.isNotBlank()) return Cmd(0, said, CmdType.YT_PLAY, q)
        }

        if (first in OPEN_START) {
            val q = words.drop(1).joinToString(" ")
            findApp(c, q)?.let { (label, pkg) -> return Cmd(0, said, CmdType.OPEN_APP, pkg, label) }
        }
        return null
    }

    private val SEARCH_START = setOf("ابحث", "ابحثلي", "دور", "دورلي", "غوغل", "جوجل", "قوقل", "google")
    private val OPEN_START = setOf("افتح", "افتحلي", "فتاح", "فتح", "شغل", "open")
    private val YT_STOP = listOf(
        "افتح", "افتحلي", "شغل", "شغلي", "شغللي", "وشغل", "على", "ع", "عال", "و", "في", "بال", "من",
        "يوتيوب", "youtube", "فيديو", "غنيه", "اغنيه"
    )

    // ------------------------------------------------------------ apps
    fun launcherApps(c: Context): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return c.packageManager.queryIntentActivities(intent, 0)
            .map { it.loadLabel(c.packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != c.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    private fun findApp(c: Context, q: String): Pair<String, String>? {
        if (q.isBlank()) return null
        return launcherApps(c)
            .map { it to (find(q, it.first)?.score ?: similarity(loose(q), loose(it.first))) }
            .filter { it.second >= 0.72 }
            .maxByOrNull { it.second }?.first
    }

    // ------------------------------------------------------------ time
    private val NUM_WORDS = mapOf(
        "واحده" to 1, "وحده" to 1, "ثنتين" to 2, "تنتين" to 2, "اثنين" to 2, "تنين" to 2,
        "ثلاث" to 3, "تلات" to 3, "ثلاثه" to 3, "تلاته" to 3, "اربع" to 4, "اربعه" to 4,
        "خمس" to 5, "خمسه" to 5, "ست" to 6, "سته" to 6, "سبع" to 7, "سبعه" to 7,
        "ثمان" to 8, "تمان" to 8, "ثمانيه" to 8, "تمانيه" to 8, "تسع" to 9, "تسعه" to 9,
        "عشر" to 10, "عشره" to 10, "حدعش" to 11, "احدعش" to 11, "طنعش" to 12, "اطنعش" to 12, "اتناعش" to 12
    )

    private fun parseTime(t: String): String? {
        var h: Int
        var m = 0
        val hm = Regex("(\\d{1,2})[:.](\\d{2})").find(t)
        if (hm != null) {
            h = hm.groupValues[1].toInt(); m = hm.groupValues[2].toInt()
        } else {
            h = Regex("(\\d{1,2})").find(t)?.groupValues?.get(1)?.toInt()
                ?: t.split(" ").firstNotNullOfOrNull { w -> NUM_WORDS[w] ?: NUM_WORDS[w.removePrefix("ال")] }
                ?: return null
            when {
                t.contains("الا ربع") -> { h -= 1; m = 45 }
                t.contains("الا ثلث") -> { h -= 1; m = 40 }
                t.contains("ونص") -> m = 30
                t.contains("وربع") -> m = 15
                t.contains("وثلث") -> m = 20
            }
        }
        if (h < 0) h = 23
        if (h < 12 && listOf("مسا", "الليل", "العصر", "بعد الضهر", "بعد الظهر").any { t.contains(it) }) h += 12
        if (h !in 0..23 || m !in 0..59) return null
        return "%02d:%02d".format(h, m)
    }
}
