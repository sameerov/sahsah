package com.sahsah.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class AssistantActivity : Activity() {

    private val REQ_VOICE = 10
    private val REQ_VIDEO = 20
    private val REQ_MIC = 30
    private val REQ_TRAIN = 40

    private lateinit var content: LinearLayout
    private val tabButtons = mutableListOf<Button>()
    private var tab = 0
    private var trainingId = 0

    // views that get refreshed
    private var result: TextView? = null
    private var listenBtn: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = Ui.screen(this, "🎤 المساعد")

        // Tabs
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(this@AssistantActivity, Ui.CARD, 16)
            setPadding(Ui.dp(context, 4), Ui.dp(context, 4), Ui.dp(context, 4), Ui.dp(context, 4))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = Ui.dp(context, 12) }
        }
        listOf("الأوامر", "الصوت", "الإعدادات").forEachIndexed { i, label ->
            val b = Button(this).apply {
                text = label; textSize = 15f; isAllCaps = false; stateListAnimator = null
                setTextColor(Ui.color(Ui.TEXT))
                setOnClickListener { tab = i; render() }
                layoutParams = LinearLayout.LayoutParams(0, Ui.dp(context, 44), 1f)
            }
            tabButtons.add(b); tabs.addView(b)
        }
        col.addView(tabs)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(content)
    }

    override fun onResume() {
        super.onResume()
        Speaker.init(this)
        render()
    }

    private fun render() {
        tabButtons.forEachIndexed { i, b ->
            b.background = if (i == tab) Ui.rounded(this, Ui.ACCENT, 12) else null
        }
        content.removeAllViews()
        when (tab) {
            0 -> renderCommands()
            1 -> renderVoice()
            else -> renderSettings()
        }
    }

    // ================================================================ tab 1
    private fun renderCommands() {
        if (AgentService.instance == null) {
            content.addView(Ui.card(this, "⚠️ المساعد مو مفعّل", "بيلزم لإرسال واتساب، البحث جوّا التطبيقات، والكتابة بكلود.").apply {
                addView(Ui.button(this@AssistantActivity, "فعّله من إمكانية الوصول", Ui.ORANGE) { openAccessibility() })
            })
        }

        // Say / type
        val say = Ui.card(this)
        say.addView(Ui.button(this, "🎤  احكي أمر", Ui.ACCENT, 22f) { listen() }.apply {
            minHeight = Ui.dp(context, 72)
        })
        val input = Ui.field(this, "أو اكتب الأمر هون…")
        say.addView(input)
        say.addView(Ui.button(this, "نفّذ", Ui.GREEN) { show(Voice.runHeard(this, listOf(input.text.toString()))) })
        result = Ui.muted(this, lastLine()).apply { setPadding(0, Ui.dp(context, 10), 0, 0) }
        say.addView(result)
        content.addView(say)

        // Saved commands
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(context, 4), Ui.dp(context, 22), 0, 0)
        }
        head.addView(TextView(this).apply {
            text = "أوامري"; textSize = 21f; setTextColor(Ui.color(Ui.TEXT)); setTypeface(typeface, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(Button(this).apply {
            text = "➕ جديد"; isAllCaps = false; stateListAnimator = null; textSize = 15f
            setTextColor(Ui.color(Ui.TEXT)); background = Ui.rounded(context, Ui.BLUE, 12)
            setPadding(Ui.dp(context, 16), 0, Ui.dp(context, 16), 0)
            setOnClickListener { newCommand() }
        })
        content.addView(head)

        val cmds = Store.commands(this)
        if (cmds.isEmpty()) content.addView(Ui.card(this, null, "ما في أوامر لسا. اضغط «➕ جديد» لتعمل أول أمر."))
        cmds.forEach { cmd -> content.addView(commandCard(cmd)) }

        // Scheduled
        val tasks = Store.tasks(this)
        if (tasks.isNotEmpty()) {
            val sc = Ui.card(this, "⏰ المجدولة")
            tasks.forEach { t ->
                val name = Store.findCommand(this, t.cmdId)?.name ?: "؟"
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, Ui.dp(context, 10), 0, 0)
                }
                row.addView(
                    Ui.body(this, "%02d:%02d · %s\n«%s»".format(t.hour, t.minute, if (t.daily) "كل يوم" else "مرة وحدة", name), 15f),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                )
                row.addView(Button(this).apply {
                    text = "حذف"; isAllCaps = false; stateListAnimator = null
                    setTextColor(Ui.color(Ui.TEXT)); background = Ui.rounded(context, Ui.GREY, 10)
                    setOnClickListener { Scheduler.cancel(context, t.id); Store.removeTask(context, t.id); render() }
                })
                sc.addView(row)
            }
            content.addView(sc)
        }
    }

    private fun commandCard(cmd: Cmd): LinearLayout {
        val card = Ui.card(this, "«${cmd.name}»", cmd.describe())
        if (cmd.aliases.isNotEmpty()) {
            card.addView(Ui.muted(this, "🧠 تعلّم: " + cmd.aliases.joinToString("، ") { "«$it»" }).apply {
                setPadding(0, Ui.dp(context, 6), 0, 0); setTextColor(Ui.color("#8F7DFF"))
            })
        }
        card.addView(Ui.row(this,
            "▶ شغّل" to { show(Executor.run(AgentService.instance ?: this, cmd)) },
            "🎤 علّمه" to { train(cmd) },
            "⏰" to { schedule(cmd) },
            "⋯" to { moreMenu(cmd) }
        ))
        return card
    }

    private fun moreMenu(cmd: Cmd) {
        val items = mutableListOf("🗑 حذف الأمر")
        if (cmd.aliases.isNotEmpty()) items.add("🧹 مسح اللي تعلّمه")
        AlertDialog.Builder(this).setTitle("«${cmd.name}»")
            .setItems(items.toTypedArray()) { _, i ->
                when (items[i]) {
                    "🗑 حذف الأمر" -> AlertDialog.Builder(this).setMessage("تحذف «${cmd.name}»؟")
                        .setPositiveButton("حذف") { _, _ -> Store.removeCommand(this, cmd.id); render() }
                        .setNegativeButton("لا", null).show()
                    else -> { Store.clearAliases(this, cmd.id); render() }
                }
            }.show()
    }

    private fun lastLine(): String {
        val h = Store.heard(this)
        val l = Store.last(this)
        return buildList {
            if (h.isNotBlank()) add("آخر شي سمعته: «$h»")
            if (l.isNotBlank()) add("آخر نتيجة: $l")
        }.joinToString("\n")
    }

    // ================================================================ tab 2
    private fun renderVoice() {
        // Wake word
        val wake = Ui.card(this, "👂 التفعيل بكلمة",
            "بيضل يسمع حتى لو سكّرت التطبيق، وما بيتحرك إلا لما يسمع كلمة التفعيل. مثال: «يا مساعد يلا ماث صفحة ١٢».")
        val wakeField = Ui.field(this, "كلمة التفعيل", ListenService.wakeWord(this))
        wake.addView(wakeField)
        listenBtn = Ui.button(this, "", Ui.TEAL, 19f) {
            ListenService.setWakeWord(this, wakeField.text.toString())
            toggleListening()
        }
        wake.addView(listenBtn)
        val mute = Ui.button(this, "", Ui.GREY) {
            ListenService.setMuteBeep(this, !ListenService.muteBeep(this))
            if (ListenService.running) { ListenService.stop(this); ListenService.start(this) }
            render()
        }
        mute.text = if (ListenService.muteBeep(this)) "🔕 صوت «التك» مكتوم" else "🔔 صوت «التك» شغّال"
        wake.addView(mute)
        wake.addView(Ui.muted(this, "الكتم بيسكّت كمان أصوات الإشعارات وقت الاستماع شغّال.").apply {
            setPadding(0, Ui.dp(context, 6), 0, 0)
        })
        content.addView(wake)
        refreshListen()

        // Side key
        content.addView(Ui.card(this, "⚡ أسرع طريقة: الزر الجانبي",
            "بدون ما يضل المايك شغّال وبدون بطارية:\n" +
            "الإعدادات ▸ الميزات المتقدمة ▸ المفتاح الجانبي ▸ الضغط مرتين ▸ فتح تطبيق ▸ «أمر صوتي».\n" +
            "بعدها بتضغط الزر الجانبي مرتين وبتحكي الأمر فوراً."))

        // Assistant voice
        val v = Ui.card(this, "🔊 صوت المساعد")
        val onBtn = Ui.button(this, if (Speaker.enabled(this)) "🔊 بيحكي النتيجة: شغّال" else "🔇 بيحكي النتيجة: طافي") {
            Speaker.setEnabled(this, !Speaker.enabled(this)); render()
        }
        v.addView(onBtn)
        val genders = Ui.row(this,
            "👨 ذكر شبابي" to { Speaker.setMale(this, true); render(); testVoice() },
            "👩 أنثى ناعم" to { Speaker.setMale(this, false); render(); testVoice() }
        )
        val male = Speaker.isMale(this)
        (genders.getChildAt(0) as Button).background = Ui.rounded(this, if (male) Ui.BLUE else Ui.GREY, 12)
        (genders.getChildAt(1) as Button).background = Ui.rounded(this, if (!male) Ui.PINK else Ui.GREY, 12)
        v.addView(genders)
        v.addView(Ui.row(this,
            "🎚 اختار الصوت" to { pickVoice() },
            "🔈 تجربة" to { testVoice() }
        ))
        content.addView(v)
    }

    private fun refreshListen() {
        val b = listenBtn ?: return
        val on = ListenService.running
        b.text = if (on) "⏹ وقّف الاستماع" else "👂 شغّل الاستماع"
        Ui.paint(b, if (on) Ui.RED else Ui.TEAL)
    }

    private fun toggleListening() {
        if (ListenService.running) {
            ListenService.stop(this)
            content.postDelayed({ refreshListen() }, 300)
            return
        }
        val need = buildList {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), REQ_MIC); return }
        ListenService.start(this)
        show("👂 صار يسمع. قول «${ListenService.wakeWord(this)}» وبعدها الأمر")
        content.postDelayed({ refreshListen() }, 300)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_MIC) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) toggleListening()
            else show("بدون صلاحية المايك ما بيقدر يسمع")
        }
    }

    private fun testVoice() {
        val msg = if (Speaker.isMale(this)) "أهلين، أنا مساعدك. شو بدك أعمل؟" else "أهلين، أنا مساعدتك. شو بدك أعمل؟"
        Speaker.say(this, msg, force = true)
    }

    private fun pickVoice() {
        Speaker.init(this) {
            runOnUiThread {
                val voices = Speaker.arabicVoices()
                if (voices.isEmpty()) {
                    AlertDialog.Builder(this)
                        .setMessage("ما في أصوات عربية مثبتة.\n\nنزّلها من: الإعدادات ▸ الإدارة العامة ▸ تحويل النص إلى كلام ▸ ⚙️ ▸ تثبيت بيانات الصوت ▸ العربية.")
                        .setPositiveButton("فتح الإعدادات") { _, _ ->
                            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { }
                        }
                        .setNegativeButton("لاحقاً", null).show()
                    return@runOnUiThread
                }
                val male = Speaker.isMale(this)
                AlertDialog.Builder(this)
                    .setTitle(if (male) "الصوت الذكوري" else "الصوت الأنثوي")
                    .setItems(voices.mapIndexed { i, v -> Speaker.voiceLabel(v, i) }.toTypedArray()) { _, i ->
                        Speaker.saveVoice(this, male, voices[i].name); testVoice()
                    }.show()
            }
        }
    }

    // ================================================================ tab 3
    private fun renderSettings() {
        val on = AgentService.instance != null
        content.addView(Ui.card(this, if (on) "✅ المساعد مفعّل" else "⚠️ المساعد مو مفعّل",
            "بيلزم لإرسال واتساب لحاله، البحث جوّا التطبيقات، الكتابة بكلود، وفتح الأقسام.\n" +
            "إمكانية الوصول ▸ التطبيقات المثبتة ▸ مساعد صح صح ▸ تشغيل.\n" +
            "إذا كان رمادي: الإعدادات ▸ التطبيقات ▸ صح صح ▸ ⋮ ▸ السماح بالإعدادات المقيدة.").apply {
            addView(Ui.button(this@AssistantActivity, "فتح إمكانية الوصول", if (on) Ui.GREY else Ui.ORANGE) { openAccessibility() })
        })

        if (Build.VERSION.SDK_INT >= 31 && !Scheduler.canExact(this)) {
            content.addView(Ui.card(this, "⏰ المنبهات الدقيقة", "لحتى تشتغل الأوامر المجدولة بوقتها بالضبط.").apply {
                addView(Ui.button(this@AssistantActivity, "اسمح", Ui.ORANGE) {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                })
            })
        }

        content.addView(Ui.card(this, "💡 أوامر جاهزة بدون ما تحفظها",
            "• ابحث عن …\n• شغّل … على يوتيوب\n• منبّه الساعة ٧ ونص\n• افتح [اسم التطبيق]"))

        content.addView(Ui.card(this, "🧠 إذا ما فهم أمر",
            "اضغط «🎤 علّمه» جنب الأمر وقول اسمه متل ما بتحكيه عادةً. بيحفظ كيف جوالك بيسمعه، وبيتعرّف عليه بعدها أسهل. كرّرها ٢-٣ مرات إذا لزم."))

        content.addView(Ui.card(this, "🔒 المهام المجدولة والجوال مقفول",
            "إذا الجوال مقفول برمز ما بيقدر يفتحه. فعّل Smart Lock / Extend Unlock من إعدادات شاشة القفل ليضل مفتوح بالبيت."))
    }

    // ================================================================ voice input
    private fun listen() {
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Voice.intent(), REQ_VOICE)
        } catch (_: ActivityNotFoundException) {
            show("ما في خدمة تعرّف على الصوت بالجوال. نزّل تطبيق Google من المتجر")
        }
    }

    private fun train(cmd: Cmd) {
        trainingId = cmd.id
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(
                Voice.intent().putExtra(RecognizerIntent.EXTRA_PROMPT, "قول «${cmd.name}» بس"), REQ_TRAIN
            )
        } catch (_: ActivityNotFoundException) {
            show("ما في خدمة تعرّف على الصوت بالجوال")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_VOICE -> show(Voice.handle(this, data))
            REQ_TRAIN -> {
                val heard = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) ?: return
                val added = Store.addAliases(this, trainingId, heard)
                show(if (added.isEmpty()) "👍 بيعرفه من قبل" else "🧠 تعلّم: " + added.joinToString("، ") { "«$it»" })
                render()
            }
            REQ_VIDEO -> {
                val uri = data?.data ?: return
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
                val title = fileName(uri)
                askName(CmdType.VIDEO_FILE, uri.toString(), title, "", "شغل $title")
            }
        }
    }

    private fun fileName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0).substringBeforeLast('.')
        }
        return "الفيديو"
    }

    // ================================================================ new command flow
    private fun newCommand() {
        val types = CmdType.values()
        AlertDialog.Builder(this)
            .setTitle("شو بدك يعمل الأمر؟")
            .setItems(types.map { it.label }.toTypedArray()) { _, i -> askParams(types[i]) }
            .show()
    }

    private fun askParams(type: CmdType) {
        when (type) {
            CmdType.OPEN_APP -> pickApp { label, pkg -> askName(type, pkg, label, "", label) }
            CmdType.APP_PAGE -> pickApp { label, pkg ->
                ask("اسم القسم متل ما هو مكتوب بالتطبيق", "التنزيلات") { section ->
                    askName(type, pkg, label, section, "$label $section")
                }
            }
            CmdType.APP_SEARCH -> pickApp { label, pkg ->
                ask(
                    "بحث احتياطي (اختياري)\n\nلما تقول «$label صفحة ٤٥ تمرين ٣» بيبحث عن «صفحة ٤٥ تمرين ٣». إذا ما قلت شي بعد الاسم، بيبحث عن اللي بتكتبه هون.",
                    "", allowEmpty = true
                ) { q -> askName(type, pkg, label, q, label) }
            }
            CmdType.CHAT_TYPE -> ask(
                "الصق رابط المحادثة (اختياري)\n\nمن كلود: افتح المحادثة ▸ مشاركة ▸ نسخ الرابط. إذا تركته فاضي بيفتح كلود عادي.",
                "", allowEmpty = true
            ) { link ->
                ask(
                    "رسالة احتياطية (اختياري)\n\nلما تقول «اسأل كلود شو الطقس» بيكتب «شو الطقس». إذا ما قلت شي بعد الاسم، بيكتب اللي هون.",
                    "", allowEmpty = true
                ) { msg -> askName(type, link, "Claude", msg, "اسأل كلود") }
            }
            CmdType.YT_PLAYLIST -> ask(
                "الصق رابط البلاي ليست\n(من يوتيوب: افتح البلاي ليست ▸ مشاركة ▸ نسخ الرابط)", ""
            ) { link -> askName(type, link, "", "", "البلاي ليست") }
            CmdType.YT_PLAY -> ask("شو بدك يشغّل على يوتيوب؟", "") { q -> askName(type, q, "", "", "شغل $q") }
            CmdType.WA_MSG -> askTwo(
                "لمين؟ الاسم متل ما هو بواتساب (شخص أو مجموعة)، أو الرقم مع رمز البلد مثل 9639xxxxxxxx",
                "نص الرسالة"
            ) { to, msg -> askName(type, to, msg, "", "ابعت ل$to") }
            CmdType.WEB_SEARCH -> ask("شو بدك يبحث بغوغل؟", "") { q -> askName(type, q, "", "", "ابحث $q") }
            CmdType.ALARM -> TimePickerDialog(this, { _, h, m ->
                askName(type, "%02d:%02d".format(h, m), "", "", "منبه الصبح")
            }, 7, 0, true).show()
            CmdType.VIDEO_FILE -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*")
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_VIDEO)
            }
        }
    }

    private fun askName(type: CmdType, a: String, b: String, extra: String, suggestion: String) {
        ask("سمّي الأمر\n\nهي الكلمة اللي رح تقولها لتشغّله. خليها قصيرة وواضحة.", suggestion) { name ->
            Store.addCommand(this, name, type, a, b, extra)
            show("✅ انحفظ «$name». جرّب «🎤 علّمه» عليه مرة.")
            render()
        }
    }

    private fun schedule(cmd: Cmd) {
        if (!Scheduler.canExact(this) && Build.VERSION.SDK_INT >= 31) {
            show("اسمح بالمنبهات الدقيقة أولاً، وارجع اضغط ⏰")
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        TimePickerDialog(this, { _, h, m ->
            AlertDialog.Builder(this)
                .setTitle("«${cmd.name}» الساعة %02d:%02d".format(h, m))
                .setPositiveButton("كل يوم") { _, _ -> addTask(cmd, h, m, true) }
                .setNegativeButton("مرة وحدة") { _, _ -> addTask(cmd, h, m, false) }
                .show()
        }, 16, 0, true).show()
    }

    private fun addTask(cmd: Cmd, h: Int, m: Int, daily: Boolean) {
        val t = Store.addTask(this, cmd.id, h, m, daily)
        Scheduler.schedule(this, t)
        show("⏰ انجدول «${cmd.name}» الساعة %02d:%02d".format(h, m))
        render()
    }

    // ================================================================ helpers
    private fun show(msg: String) {
        val h = Store.heard(this)
        result?.text = if (h.isBlank()) msg else "$msg\nآخر شي سمعته: «$h»"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        Speaker.say(this, msg)
    }

    private fun openAccessibility() = startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    private fun pickApp(onPick: (String, String) -> Unit) {
        val apps = Parser.launcherApps(this)
        AlertDialog.Builder(this)
            .setTitle("اختار التطبيق")
            .setItems(apps.map { it.first }.toTypedArray()) { _, i -> onPick(apps[i].first, apps[i].second) }
            .show()
    }

    private fun ask(question: String, default: String, allowEmpty: Boolean = false, onOk: (String) -> Unit) {
        val field = EditText(this).apply { setText(default); setSelection(default.length) }
        val box = LinearLayout(this).apply {
            setPadding(Ui.dp(context, 20), Ui.dp(context, 4), Ui.dp(context, 20), 0); addView(field,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setMessage(question)
            .setView(box)
            .setPositiveButton("تمام") { _, _ ->
                val v = field.text.toString().trim()
                if (v.isEmpty() && !allowEmpty) show("ما كتبت شي") else onOk(v)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun askTwo(q1: String, q2: String, onOk: (String, String) -> Unit) {
        val f1 = EditText(this)
        val f2 = EditText(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 20), Ui.dp(context, 10), Ui.dp(context, 20), 0)
            addView(TextView(context).apply { text = q1 }); addView(f1)
            addView(TextView(context).apply { text = q2; setPadding(0, Ui.dp(context, 12), 0, 0) }); addView(f2)
        }
        AlertDialog.Builder(this)
            .setView(box)
            .setPositiveButton("تمام") { _, _ ->
                val a = f1.text.toString().trim()
                val b = f2.text.toString().trim()
                if (a.isEmpty() || b.isEmpty()) show("لازم تعبّي الخانتين") else onOk(a, b)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
