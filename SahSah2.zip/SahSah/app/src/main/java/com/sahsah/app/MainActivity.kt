package com.sahsah.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var toggle: Button
    private lateinit var status: TextView
    private val nm by lazy { getSystemService(NotificationManager::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = Ui.screen(this, "صح صح", "رد تلقائي، رفض مكالمات، ومساعد صوتي")

        // ---- Do-not-disturb mode ----
        val modeCard = Ui.card(this, "🔕 وضع مشغول", "لما يكون شغّال: بيرد على واتساب، بيرفض المكالمات، وبيخفي الإشعارات.")
        status = Ui.body(this, "").apply { setPadding(0, Ui.dp(this@MainActivity, 10), 0, 0) }
        modeCard.addView(status)
        toggle = Ui.button(this, "", Ui.GREEN, 22f) { onToggle() }
        modeCard.addView(toggle)
        col.addView(modeCard)

        // ---- Auto-reply text ----
        val replyCard = Ui.card(this, "💬 الرد التلقائي", "الجملة اللي بيبعتها لكل حدا بيراسلك على واتساب.")
        val replyField = Ui.field(this, "صح صح", State.replyText(this))
        replyCard.addView(replyField)
        replyCard.addView(Ui.button(this, "حفظ الرد") {
            State.setReplyText(this, replyField.text.toString())
            replyField.setText(State.replyText(this))
            toast("انحفظ: ${State.replyText(this)}")
            refresh()
        })
        col.addView(replyCard)

        // ---- Assistant ----
        val asCard = Ui.card(this, "🎤 المساعد", "أوامرك الصوتية، الجدولة، والتفعيل بكلمة.")
        asCard.addView(Ui.button(this, "افتح المساعد", Ui.ACCENT, 19f) {
            startActivity(Intent(this, AssistantActivity::class.java))
        })
        col.addView(asCard)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---- permission checks ----
    private fun hasListener(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return flat.contains(packageName)
    }

    private fun hasDnd(): Boolean = nm.isNotificationPolicyAccessGranted

    private fun hasPhone(): Boolean =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED

    // ---- switch ----
    private fun onToggle() {
        if (State.isOn(this)) { turnOff(); return }
        when {
            !hasListener() -> {
                toast("فعّل «صح صح» بصفحة الوصول للإشعارات وارجع")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            !hasDnd() -> {
                toast("اسمح لـ «صح صح» بالتحكم بعدم الإزعاج وارجع")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            !hasPhone() -> requestPermissions(
                arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS), 1
            )
            else -> turnOn()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasPhone()) onToggle() else refresh()
    }

    private fun turnOn() {
        State.savePrevFilter(this, nm.currentInterruptionFilter)
        try { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS) } catch (_: Exception) { }
        State.setOn(this, true)
        refresh()
    }

    private fun turnOff() {
        State.setOn(this, false)
        if (hasDnd()) {
            try { nm.setInterruptionFilter(State.prevFilter(this)) } catch (_: Exception) { }
        }
        refresh()
    }

    private fun refresh() {
        val on = State.isOn(this)
        toggle.text = if (on) "⏹ إيقاف" else "▶ تشغيل"
        Ui.paint(toggle, if (on) Ui.RED else Ui.GREEN)

        status.text = if (on) {
            "✅ شغّال\n• بيرد بـ «${State.replyText(this)}»\n• بيرفض المكالمات\n• بيخفي الإشعارات"
        } else {
            val missing = buildList {
                if (!hasListener()) add("الوصول للإشعارات")
                if (!hasDnd()) add("التحكم بعدم الإزعاج")
                if (!hasPhone()) add("إدارة المكالمات")
            }
            if (missing.isEmpty()) "⏸ متوقف"
            else "⏸ متوقف\nلما تشغّله رح يطلب: " + missing.joinToString("، ")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
