plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.sahsah.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sahsah.app"
        minSdk = 29
        targetSdk = 34
        versionCode = 4
        versionName = "4.0"
    }

    // Fixed key so every new version installs over the old one
    signingConfigs {
        create("fixed") {
            storeFile = file("sahsah.keystore")
            storePassword = "sahsah123"
            keyAlias = "sahsah"
            keyPassword = "sahsah123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            signingConfig = signingConfigs.getByName("fixed")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
