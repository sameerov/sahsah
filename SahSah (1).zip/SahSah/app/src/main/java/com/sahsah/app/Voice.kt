package com.sahsah.app

import android.app.Activity
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.service.quicksettings.TileService
import android.widget.Toast

object Voice {
    fun intent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
        .putExtra(RecognizerIntent.EXTRA_PROMPT, "قول الأمر")
        .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)

    /** Tries every way the phone heard the sentence until one matches a command. */
    fun handle(a: Activity, data: Intent?): String {
        val heard = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) ?: return "ما سمعت شي"
        for (s in heard) {
            val cmd = Parser.parse(a, s) ?: continue
            return Executor.run(a, cmd)
        }
        return "🤔 ما بعرف هالأمر: «${heard.firstOrNull() ?: ""}»"
    }
}

/** Invisible screen opened from the quick-settings tile: listens, runs, closes. */
class VoiceActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Voice.intent(), 1)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "ما في خدمة تعرّف على الصوت بالجوال", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            val r = Voice.handle(this, data)
            Toast.makeText(this, r, Toast.LENGTH_LONG).show()
            Speaker.say(this, r)
        }
        finish()
    }
}

/** Quick-settings tile "🎤 أمر صوتي". */
class VoiceTile : TileService() {
    override fun onClick() {
        super.onClick()
        if (isLocked) unlockAndRun { launch() } else launch()
    }

    private fun launch() {
        val i = Intent(this, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
