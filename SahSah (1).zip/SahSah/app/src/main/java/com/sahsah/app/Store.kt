package com.sahsah.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** The fixed set of things the assistant can do. */
enum class CmdType(val label: String) {
    OPEN_APP("فتح تطبيق"),
    APP_PAGE("فتح تطبيق على قسم معيّن (مثلاً التنزيلات)"),
    APP_SEARCH("فتح تطبيق والبحث فيه (مثل يلا ماث، يلا عربي)"),
    CHAT_TYPE("فتح محادثة بكلود وكتابة رسالة وإرسالها"),
    YT_PLAYLIST("تشغيل البلاي ليست تبعي على يوتيوب"),
    YT_PLAY("تشغيل غنية أو فيديو على يوتيوب"),
    WA_MSG("إرسال رسالة واتساب (لشخص أو مجموعة)"),
    WEB_SEARCH("بحث بغوغل"),
    ALARM("منبّه"),
    VIDEO_FILE("تشغيل فيديو من ملفات الجوال")
}

/** A saved command. `a` and `b` hold its settings (depends on the type). */
data class Cmd(val id: Int, val name: String, val type: CmdType, val a: String, val b: String = "", val c: String = "") {
    fun describe(): String = when (type) {
        CmdType.OPEN_APP -> "يفتح $b"
        CmdType.APP_PAGE -> "يفتح $b على «$c»"
        CmdType.APP_SEARCH -> "يفتح $b ويبحث عن اللي بتقوله بعد اسم الأمر" + if (c.isNotBlank()) " (أو «$c»)" else ""
        CmdType.CHAT_TYPE -> (if (a.isBlank()) "يفتح كلود" else "يفتح المحادثة") + " ويكتب اللي بتقوله بعد اسم الأمر ويبعته" + if (c.isNotBlank()) " (أو «$c»)" else ""
        CmdType.YT_PLAYLIST -> "يشغّل البلاي ليست على يوتيوب"
        CmdType.YT_PLAY -> "يشغّل «$a» على يوتيوب"
        CmdType.WA_MSG -> "يبعت «$b» لـ $a"
        CmdType.WEB_SEARCH -> "يبحث بغوغل عن «$a»"
        CmdType.ALARM -> "يحط منبّه الساعة $a"
        CmdType.VIDEO_FILE -> "يشغّل الفيديو $b"
    }
}

data class Task(val id: Int, val cmdId: Int, val hour: Int, val minute: Int, val daily: Boolean)

object Store {
    private fun p(c: Context) = c.getSharedPreferences("assistant", Context.MODE_PRIVATE)
    private fun newId() = (System.currentTimeMillis() % 1_000_000_000L).toInt()

    // ---- commands ----
    fun commands(c: Context): List<Cmd> {
        val arr = JSONArray(p(c).getString("commands", "[]"))
        return (0 until arr.length()).mapNotNull {
            val o = arr.getJSONObject(it)
            val type = try { CmdType.valueOf(o.getString("type")) } catch (_: Exception) { null }
            type?.let { t -> Cmd(o.getInt("id"), o.getString("name"), t, o.optString("a"), o.optString("b"), o.optString("c")) }
        }
    }

    private fun saveCommands(c: Context, list: List<Cmd>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("type", it.type.name)
                    .put("a", it.a).put("b", it.b).put("c", it.c)
            )
        }
        p(c).edit().putString("commands", arr.toString()).apply()
    }

    fun addCommand(c: Context, name: String, type: CmdType, a: String, b: String, extra: String = ""): Cmd {
        val cmd = Cmd(newId(), name.trim(), type, a.trim(), b.trim(), extra.trim())
        saveCommands(c, commands(c) + cmd)
        return cmd
    }

    fun removeCommand(c: Context, id: Int) {
        saveCommands(c, commands(c).filter { it.id != id })
        tasks(c).filter { it.cmdId == id }.forEach { removeTask(c, it.id); Scheduler.cancel(c, it.id) }
    }

    fun findCommand(c: Context, id: Int) = commands(c).firstOrNull { it.id == id }

    // ---- scheduled tasks ----
    fun tasks(c: Context): List<Task> {
        val arr = JSONArray(p(c).getString("tasks", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.getInt("id"), o.getInt("cmd"), o.getInt("hour"), o.getInt("minute"), o.getBoolean("daily"))
        }
    }

    private fun saveTasks(c: Context, list: List<Task>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("cmd", it.cmdId)
                    .put("hour", it.hour).put("minute", it.minute).put("daily", it.daily)
            )
        }
        p(c).edit().putString("tasks", arr.toString()).apply()
    }

    fun addTask(c: Context, cmdId: Int, hour: Int, minute: Int, daily: Boolean): Task {
        val t = Task(newId(), cmdId, hour, minute, daily)
        saveTasks(c, tasks(c) + t)
        return t
    }

    fun removeTask(c: Context, id: Int) = saveTasks(c, tasks(c).filter { it.id != id })
    fun findTask(c: Context, id: Int) = tasks(c).firstOrNull { it.id == id }

    // ---- last result ----
    fun last(c: Context): String = p(c).getString("last", "") ?: ""
    fun setLast(c: Context, s: String) = p(c).edit().putString("last", s).apply()
}
