package com.sahsah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

/**
 * Keeps listening in the background. When it hears the wake word
 * (default «يا مساعد»), it runs the command that follows it.
 * Shows a notification while on, with a "stop" button.
 */
class ListenService : Service(), RecognitionListener {

    companion object {
        private const val ACTION_STOP = "stop"
        private const val CHANNEL = "listen"
        @Volatile var running = false

        private fun prefs(c: Context) = c.getSharedPreferences("listen", Context.MODE_PRIVATE)
        fun wakeWord(c: Context) = (prefs(c).getString("wake", "") ?: "").ifBlank { "يا مساعد" }
        fun setWakeWord(c: Context, w: String) = prefs(c).edit().putString("wake", w.trim()).apply()

        fun start(c: Context) = c.startForegroundService(Intent(c, ListenService::class.java))
        fun stop(c: Context) = c.stopService(Intent(c, ListenService::class.java))
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var awaitingUntil = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        running = true
        if (rec == null) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                toast("ما في خدمة تعرّف على الصوت بالجوال")
                stopSelf()
                return START_NOT_STICKY
            }
            rec = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
            listen()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy()
        rec = null
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "المساعد عم يسمع", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 2, Intent(this, AssistantActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("👂 المساعد عم يسمع")
            .setContentText("قول «${wakeWord(this)}» وبعدها الأمر")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(null, "إيقاف", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(7, n)
        }
    }

    // ------------------------------------------------------------ listening loop
    private fun listen() {
        if (!running) return
        try {
            rec?.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                    .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            )
        } catch (_: Exception) {
            restart(1000)
        }
    }

    private fun restart(delay: Long = 300) {
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ listen() }, delay)
    }

    override fun onResults(results: Bundle?) {
        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: emptyList()
        handle(heard)
    }

    override fun onError(error: Int) {
        when (error) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                toast("المساعد بيحتاج صلاحية المايك"); stopSelf()
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec?.cancel(); restart(1500) }
            SpeechRecognizer.ERROR_CLIENT -> restart(800)
            else -> restart(300)
        }
    }

    private fun handle(heard: List<String>) {
        val wake = Parser.norm(wakeWord(this))
        val now = System.currentTimeMillis()

        // Right after "نعم؟": the next sentence is the command
        if (now < awaitingUntil && heard.isNotEmpty()) {
            awaitingUntil = 0
            run(heard)
            return
        }

        for (s in heard) {
            val t = Parser.norm(s)
            if (!t.contains(wake)) continue
            val rest = t.substringAfter(wake).trim()
            if (rest.isEmpty()) {
                awaitingUntil = now + 8000
                Speaker.say(this, "نعم؟", force = true)
                restart(1200)
            } else {
                run(listOf(rest) + heard.map { Parser.norm(it).substringAfter(wake).trim() })
            }
            return
        }
        restart()
    }

    private fun run(options: List<String>) {
        val ctx = AgentService.instance ?: this
        val cmd = options.firstNotNullOfOrNull { Parser.parse(this, it) }
        val r = if (cmd == null) "ما بعرف هالأمر" else Executor.run(ctx, cmd)
        toast(r)
        Speaker.say(this, r)
        restart(3500) // give the assistant time to finish talking
    }

    private fun toast(s: String) = Handler(Looper.getMainLooper()).post { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    // unused callbacks
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
}
