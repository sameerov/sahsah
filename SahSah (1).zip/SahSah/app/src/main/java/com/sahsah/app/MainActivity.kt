package com.sahsah.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var toggle: Button
    private lateinit var status: TextView
    private val nm by lazy { getSystemService(NotificationManager::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(60, 60, 60, 60)
        }
        val title = TextView(this).apply {
            text = "صح صح"
            textSize = 40f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 60)
        }
        toggle = Button(this).apply {
            textSize = 26f
            setPadding(0, 40, 0, 40)
            setOnClickListener { onToggle() }
        }
        status = TextView(this).apply {
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 50, 0, 0)
        }
        root.addView(title)

        // Custom auto-reply text
        val replyLabel = TextView(this).apply {
            text = "الرد التلقائي:"
            textSize = 16f
        }
        val replyField = EditText(this).apply {
            setText(State.replyText(this@MainActivity))
            textSize = 20f
            gravity = Gravity.CENTER
            hint = "صح صح"
        }
        val saveReply = Button(this).apply {
            text = "حفظ الرد"
            setOnClickListener {
                State.setReplyText(this@MainActivity, replyField.text.toString())
                replyField.setText(State.replyText(this@MainActivity))
                toast("انحفظ: ${State.replyText(this@MainActivity)}")
                refresh()
            }
        }
        root.addView(replyLabel)
        root.addView(
            replyField,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(
            saveReply,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 50 }
        )

        root.addView(
            toggle,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        root.addView(status)
        root.addView(
            Button(this).apply {
                text = "🎤 المساعد"
                textSize = 20f
                setOnClickListener { startActivity(Intent(this@MainActivity, AssistantActivity::class.java)) }
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 80 }
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---- permission checks ----
    private fun hasListener(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return flat.contains(packageName)
    }

    private fun hasDnd(): Boolean = nm.isNotificationPolicyAccessGranted

    private fun hasPhone(): Boolean =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED

    // ---- switch ----
    private fun onToggle() {
        if (State.isOn(this)) {
            turnOff()
            return
        }
        when {
            !hasListener() -> {
                toast("فعّل «صح صح» في صفحة الوصول للإشعارات ثم ارجع")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            !hasDnd() -> {
                toast("اسمح لـ «صح صح» بالتحكم في وضع عدم الإزعاج ثم ارجع")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            !hasPhone() -> requestPermissions(
                arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS),
                1
            )
            else -> turnOn()
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (hasPhone()) onToggle() else refresh()
    }

    private fun turnOn() {
        // Silence everything except alarms, remembering the previous mode
        State.savePrevFilter(this, nm.currentInterruptionFilter)
        try {
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
        } catch (_: Exception) { }
        State.setOn(this, true)
        toast("تم التشغيل")
        refresh()
    }

    private fun turnOff() {
        State.setOn(this, false)
        if (hasDnd()) {
            try {
                nm.setInterruptionFilter(State.prevFilter(this))
            } catch (_: Exception) { }
        }
        toast("تم الإيقاف")
        refresh()
    }

    private fun refresh() {
        val on = State.isOn(this)
        toggle.text = if (on) "إيقاف" else "تشغيل"
        toggle.setBackgroundColor(if (on) Color.parseColor("#C62828") else Color.parseColor("#2E7D32"))
        toggle.setTextColor(Color.WHITE)

        status.text = if (on) {
            "شغّال ✅\n\n• يرد على رسائل واتساب بـ «${State.replyText(this)}»\n• يرفض المكالمات\n• يحجب الإشعارات"
        } else {
            val missing = buildList {
                if (!hasListener()) add("• الوصول للإشعارات")
                if (!hasDnd()) add("• التحكم في عدم الإزعاج")
                if (!hasPhone()) add("• إدارة المكالمات")
            }
            if (missing.isEmpty()) "متوقف"
            else "متوقف\n\nعند الضغط على تشغيل سيطلب هذه الصلاحيات:\n" + missing.joinToString("\n")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
