package com.sahsah.app

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore

/** Runs one command. Returns a short message about what happened. */
object Executor {
    private const val YOUTUBE = "com.google.android.youtube"
    private val WHATSAPP = listOf("com.whatsapp", "com.whatsapp.w4b")

    fun run(c: Context, cmd: Cmd): String = (try {
        when (cmd.type) {
            CmdType.OPEN_APP -> openApp(c, cmd.a, cmd.b)
            CmdType.APP_PAGE -> openPage(c, cmd.a, cmd.b, cmd.c)
            CmdType.APP_SEARCH -> appSearch(c, cmd.a, cmd.b, cmd.c)
            CmdType.CHAT_TYPE -> chatType(c, cmd.a, cmd.c)
            CmdType.YT_PLAYLIST -> playlist(c, cmd.a)
            CmdType.YT_PLAY -> playOnYoutube(c, cmd.a)
            CmdType.WA_MSG -> whatsapp(c, cmd.a, cmd.b)
            CmdType.WEB_SEARCH -> search(c, cmd.a)
            CmdType.ALARM -> alarm(c, cmd.a)
            CmdType.VIDEO_FILE -> video(c, cmd.a, cmd.b)
        }
    } catch (e: Exception) {
        "❌ ${e.message}"
    }).also { Store.setLast(c, "${cmd.name}: $it") }

    private fun start(c: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    private fun openApp(c: Context, pkg: String, label: String): String {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return "❌ $label مو مثبت"
        start(c, i)
        return "✅ فتحت $label"
    }

    private fun openPage(c: Context, pkg: String, label: String, section: String): String {
        val agent = AgentService.instance ?: return "❌ فتح قسم معيّن بيحتاج تفعيل المساعد بإمكانية الوصول"
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return "❌ $label مو مثبت"
        start(c, i)
        agent.tapSection(section)
        return "⏳ عم يفتح $label على «$section»"
    }

    private fun appSearch(c: Context, pkg: String, label: String, query: String): String {
        if (query.isBlank()) return "❌ قول شو بدك تبحث بعد اسم الأمر، مثلاً: $label صفحة ٤٥ تمرين ٣"
        val agent = AgentService.instance ?: return "❌ البحث جوّا التطبيق بيحتاج تفعيل المساعد بإمكانية الوصول"
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return "❌ $label مو مثبت"
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        start(c, i)
        agent.searchInApp(query)
        return "🔎 عم يبحث بـ $label عن «$query»"
    }

    private const val CLAUDE = "com.anthropic.claude"

    private fun chatType(c: Context, link: String, text: String): String {
        if (text.isBlank()) return "❌ قول شو بدك يكتب بعد اسم الأمر"
        val agent = AgentService.instance ?: return "❌ الكتابة بالمحادثة بتحتاج تفعيل المساعد بإمكانية الوصول"
        if (link.isBlank()) {
            val i = c.packageManager.getLaunchIntentForPackage(CLAUDE) ?: return "❌ تطبيق Claude مو مثبت"
            start(c, i)
        } else {
            val view = Intent(Intent.ACTION_VIEW, Uri.parse(link.trim()))
            try { start(c, Intent(view).setPackage(CLAUDE)) } catch (_: ActivityNotFoundException) { start(c, view) }
        }
        agent.typeAndSend(text)
        return "✍️ عم يكتب «$text»"
    }

    private fun openYoutube(c: Context, url: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(YOUTUBE)
        try { start(c, i) } catch (_: ActivityNotFoundException) {
            start(c, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun playlist(c: Context, link: String): String {
        val id = Uri.parse(link.trim()).getQueryParameter("list")
            ?: return "❌ رابط البلاي ليست مو صحيح، لازم يكون فيه list="
        openYoutube(c, "https://www.youtube.com/watch?list=$id")
        AgentService.instance?.tapPlayAll()
        return "▶ عم يفتح البلاي ليست"
    }

    private fun playOnYoutube(c: Context, query: String): String {
        val play = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .setPackage(YOUTUBE)
            .putExtra(SearchManager.QUERY, query)
        return try {
            start(c, play)
            "▶ عم يشغّل «$query» على يوتيوب"
        } catch (_: ActivityNotFoundException) {
            openYoutube(c, "https://www.youtube.com/results?search_query=" + Uri.encode(query))
            AgentService.instance?.tapFirstVideo()
            "🔎 فتحت نتائج «$query» على يوتيوب"
        }
    }

    private fun whatsapp(c: Context, target: String, text: String): String {
        val agent = AgentService.instance
        val digits = target.filter { it.isDigit() }
        val isNumber = digits.length >= 8 && target.none { it.isLetter() }

        if (isNumber) {
            val url = "https://wa.me/$digits?text=" + Uri.encode(text)
            var opened = false
            for (pkg in WHATSAPP) {
                try {
                    start(c, Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg)); opened = true; break
                } catch (_: ActivityNotFoundException) { }
            }
            if (!opened) return "❌ واتساب مو مثبت"
            if (agent == null) return "⚠️ فتحت المحادثة والرسالة مكتوبة. فعّل المساعد بإمكانية الوصول ليضغط إرسال لحاله"
            agent.pressWhatsAppSend()
            return "⏳ عم يبعت الرسالة..."
        }

        if (agent == null) return "❌ الإرسال لاسم أو مجموعة بيحتاج تفعيل المساعد بإمكانية الوصول"
        val pkg = WHATSAPP.firstOrNull { c.packageManager.getLaunchIntentForPackage(it) != null }
            ?: return "❌ واتساب مو مثبت"
        val launch = c.packageManager.getLaunchIntentForPackage(pkg)!!
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        start(c, launch)
        agent.whatsAppSendByName(target, text)
        return "⏳ عم يبعت لـ $target..."
    }

    private fun search(c: Context, q: String): String {
        try {
            start(c, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
        } catch (_: ActivityNotFoundException) {
            start(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        }
        return "🔎 عم يبحث عن «$q»"
    }

    private fun alarm(c: Context, time: String): String {
        val (h, m) = time.split(":").map { it.trim().toInt() }
        start(
            c, Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "منبّه من المساعد")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        return "⏰ حطيت منبّه الساعة %02d:%02d".format(h, m)
    }

    private fun video(c: Context, uri: String, title: String): String {
        start(
            c, Intent(Intent.ACTION_VIEW)
                .setDataAndType(Uri.parse(uri), "video/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
        return "▶ عم يشغّل $title"
    }
}
