package com.sahsah.app

import android.content.Context
import android.content.Intent

/**
 * Turns what you said or typed into a command.
 * 1) a saved command whose name appears in the sentence
 * 2) a few built-in phrases: ابحث عن…، شغّل … على يوتيوب، منبّه الساعة…، افتح …
 * Anything else → null (not understood).
 */
object Parser {

    fun norm(s: String): String {
        val digits = s.map { ch ->
            when (ch) {
                in '٠'..'٩' -> '0' + (ch - '٠')
                in '۰'..'۹' -> '0' + (ch - '۰')
                else -> ch
            }
        }.joinToString("")
        return digits.lowercase()
            .replace(Regex("[ً-ْـ]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ى', 'ي').replace('ة', 'ه')
            .replace(Regex("[،,؟?!.]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun parse(c: Context, raw: String): Cmd? {
        val t = norm(raw)
        if (t.isEmpty()) return null

        // 1. saved commands (longest matching name wins)
        Store.commands(c)
            .filter { norm(it.name).isNotEmpty() && t.contains(norm(it.name)) }
            .maxByOrNull { norm(it.name).length }
            ?.let { cmd ->
                if (cmd.type == CmdType.APP_SEARCH || cmd.type == CmdType.CHAT_TYPE) {
                    // whatever you said after the name is what to search / write
                    val rest = (if (raw.contains(cmd.name)) raw.substringAfter(cmd.name)
                                else t.substringAfter(norm(cmd.name))).trim()
                    if (rest.isNotEmpty()) return cmd.copy(c = rest)
                }
                return cmd
            }

        // 2. built-in phrases
        afterPrefix(t, listOf("ابحث عن", "ابحثلي عن", "دور على", "دورلي على", "ابحث", "غوغل", "جوجل"))
            ?.let { return Cmd(0, raw, CmdType.WEB_SEARCH, it) }

        if (t.contains("منبه")) parseTime(t)?.let { return Cmd(0, raw, CmdType.ALARM, it) }

        if (t.contains("يوتيوب")) {
            val q = t.split(" ").filter { it !in YT_STOP }.joinToString(" ").trim()
            if (q.isNotEmpty()) return Cmd(0, raw, CmdType.YT_PLAY, q)
        }

        afterPrefix(t, listOf("افتحلي", "افتح", "شغل تطبيق"))?.let { q ->
            findApp(c, q)?.let { (label, pkg) -> return Cmd(0, raw, CmdType.OPEN_APP, pkg, label) }
        }
        return null
    }

    private val YT_STOP = setOf(
        "افتح", "افتحلي", "شغل", "شغلي", "شغللي", "وشغل", "على", "ع", "عال", "و", "في", "بال",
        "يوتيوب", "اليوتيوب", "عاليوتيوب", "باليوتيوب", "بيوتيوب", "فيديو", "غنيه", "اغنيه", "الغنيه"
    )

    private fun afterPrefix(t: String, prefixes: List<String>): String? {
        for (p in prefixes.sortedByDescending { it.length }) {
            if (t.startsWith("$p ")) return t.removePrefix(p).trim().ifEmpty { null }
        }
        return null
    }

    // ---- apps ----
    fun launcherApps(c: Context): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return c.packageManager.queryIntentActivities(intent, 0)
            .map { it.loadLabel(c.packageManager).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    private fun findApp(c: Context, q: String): Pair<String, String>? {
        val apps = launcherApps(c)
        val nq = norm(q)
        return apps.firstOrNull { norm(it.first) == nq }
            ?: apps.firstOrNull { norm(it.first).contains(nq) || nq.contains(norm(it.first)) }
    }

    // ---- time: "منبه الساعة 7 ونص المسا", "منبه 6:45" ----
    private val NUM_WORDS = mapOf(
        "واحده" to 1, "وحده" to 1, "ثنتين" to 2, "تنتين" to 2, "اثنين" to 2, "تنين" to 2,
        "ثلاث" to 3, "تلات" to 3, "ثلاثه" to 3, "تلاته" to 3, "اربع" to 4, "اربعه" to 4,
        "خمس" to 5, "خمسه" to 5, "ست" to 6, "سته" to 6, "سبع" to 7, "سبعه" to 7,
        "ثمان" to 8, "تمان" to 8, "ثمانيه" to 8, "تمانيه" to 8, "تسع" to 9, "تسعه" to 9,
        "عشر" to 10, "عشره" to 10, "حدعش" to 11, "احدعش" to 11, "طنعش" to 12, "اطنعش" to 12, "اتناعش" to 12
    )

    private fun parseTime(t: String): String? {
        var h: Int
        var m = 0
        val hm = Regex("(\\d{1,2})[:.](\\d{2})").find(t)
        if (hm != null) {
            h = hm.groupValues[1].toInt(); m = hm.groupValues[2].toInt()
        } else {
            h = Regex("(\\d{1,2})").find(t)?.groupValues?.get(1)?.toInt()
                ?: t.split(" ").firstNotNullOfOrNull { w -> NUM_WORDS[w] ?: NUM_WORDS[w.removePrefix("ال")] }
                ?: return null
            when {
                t.contains("الا ربع") -> { h -= 1; m = 45 }
                t.contains("الا ثلث") -> { h -= 1; m = 40 }
                t.contains("ونص") -> m = 30
                t.contains("وربع") -> m = 15
                t.contains("وثلث") -> m = 20
            }
        }
        if (h < 0) h = 23
        if (h < 12 && listOf("مسا", "الليل", "العصر", "بعد الضهر", "بعد الظهر").any { t.contains(it) }) h += 12
        if (h !in 0..23 || m !in 0..59) return null
        return "%02d:%02d".format(h, m)
    }
}
