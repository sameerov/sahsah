package com.sahsah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import java.util.Calendar

/** Sets alarms for scheduled commands. */
object Scheduler {
    private fun pending(c: Context, id: Int): PendingIntent {
        val i = Intent(c, TaskReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(
            c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canExact(c: Context): Boolean {
        val am = c.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun schedule(c: Context, t: Task) {
        val am = c.getSystemService(AlarmManager::class.java)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, t.hour)
            set(Calendar.MINUTE, t.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = pending(c, t.id)
        if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    fun cancel(c: Context, id: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(pending(c, id))
    }

    fun rescheduleAll(c: Context) = Store.tasks(c).forEach { schedule(c, it) }
}

/** Fires when a scheduled command's time comes. */
class TaskReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val task = Store.findTask(c, id) ?: return
        val cmd = Store.findCommand(c, task.cmdId)
        if (task.daily && cmd != null) Scheduler.schedule(c, task) else Store.removeTask(c, id)
        if (cmd == null) return

        // Turn the screen on
        val pm = c.getSystemService(PowerManager::class.java)
        @Suppress("DEPRECATION")
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "sahsah:task"
        ).acquire(60_000L)

        // Starting other apps from the background is allowed while the helper is on
        val result = Executor.run(AgentService.instance ?: c, cmd)
        Speaker.say(c, result)
    }
}

/** Puts the alarms back after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.rescheduleAll(c)
    }
}
