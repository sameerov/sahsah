package com.sahsah.app

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class AssistantActivity : Activity() {

    private lateinit var accessStatus: TextView
    private lateinit var input: EditText
    private lateinit var result: TextView
    private lateinit var cmdBox: LinearLayout
    private lateinit var taskBox: LinearLayout
    private lateinit var voiceToggle: Button
    private lateinit var listenBtn: Button
    private lateinit var wakeField: EditText
    private val REQ_MIC = 30
    private lateinit var maleBtn: Button
    private lateinit var femaleBtn: Button

    private val REQ_VOICE = 10
    private val REQ_VIDEO = 20

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 100)
        }

        col.addView(title("🎤 المساعد", 30f))

        accessStatus = text("")
        col.addView(accessStatus)
        col.addView(button("فتح إعدادات إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        // Speak / type a command
        col.addView(title("قول أو اكتب أمر", 20f))
        col.addView(button("🎤 احكي", "#6A1B9A", 26f) { listen() })
        input = EditText(this).apply { hint = "أو اكتب الأمر هون"; textSize = 18f }
        col.addView(input)
        col.addView(button("نفّذ", "#2E7D32") {
            val cmd = Parser.parse(this, input.text.toString())
            show(if (cmd == null) "🤔 ما بعرف هالأمر" else Executor.run(this, cmd))
        })
        result = text("").apply { textSize = 17f; setPadding(0, 16, 0, 0) }
        col.addView(result)

        // Wake word: listens even when the app is closed
        col.addView(title("👂 التفعيل الصوتي", 20f))
        col.addView(text("بيضل يسمع حتى لو التطبيق مسكّر. قول كلمة التفعيل وبعدها الأمر، مثلاً: «يا مساعد شغّل البلاي ليست»."))
        wakeField = EditText(this).apply { setText(ListenService.wakeWord(this@AssistantActivity)); textSize = 18f }
        col.addView(wakeField)
        listenBtn = button("", null) { toggleListening() }
        col.addView(listenBtn)

        // Voice of the assistant
        col.addView(title("🔊 صوت المساعد", 20f))
        voiceToggle = button("", null) {
            Speaker.setEnabled(this, !Speaker.enabled(this)); refreshVoice()
        }
        col.addView(voiceToggle)
        val genderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        maleBtn = smallButton("👨 ذكر شبابي") { Speaker.setMale(this, true); refreshVoice(); testVoice() }
        femaleBtn = smallButton("👩 أنثى ناعم") { Speaker.setMale(this, false); refreshVoice(); testVoice() }
        genderRow.addView(maleBtn); genderRow.addView(femaleBtn)
        col.addView(genderRow)
        val voiceRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        voiceRow.addView(smallButton("🎚 اختار الصوت") { pickVoice() })
        voiceRow.addView(smallButton("🔈 تجربة") { testVoice() })
        col.addView(voiceRow)

        // Saved commands
        col.addView(title("أوامري", 20f))
        col.addView(button("➕ أمر جديد", "#1565C0") { newCommand() })
        cmdBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(cmdBox)

        // Scheduled
        col.addView(title("المجدولة", 20f))
        taskBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(taskBox)

        // Help
        col.addView(title("أوامر جاهزة بتقدر تقولها", 20f))
        col.addView(text(
            "• ابحث عن …\n" +
            "• شغّل … على يوتيوب\n" +
            "• منبّه الساعة ٧ ونص (أو: منبّه ٦:٤٥)\n" +
            "• افتح [اسم التطبيق]\n" +
            "• أو اسم أي أمر من «أوامري»\n\n" +
            "💡 لتحكي بدون ما تفتح التطبيق: نزّل لوحة الإعدادات السريعة ▸ ✏️ تعديل ▸ اسحب زر «أمر صوتي» لفوق."
        ))

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        Speaker.init(this)
        refresh()
        refreshVoice()
    }

    // ------------------------------------------------------------ voice settings
    private fun toggleListening() {
        if (ListenService.running) {
            ListenService.stop(this)
            listenBtn.postDelayed({ refreshVoice() }, 300)
            return
        }
        ListenService.setWakeWord(this, wakeField.text.toString())
        val need = buildList {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                add(android.Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), REQ_MIC); return }
        ListenService.start(this)
        show("👂 صار يسمع. قول «${ListenService.wakeWord(this)}» وبعدها الأمر")
        listenBtn.postDelayed({ refreshVoice() }, 300)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == REQ_MIC) {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
                toggleListening()
            else show("بدون صلاحية المايك ما بيقدر يسمع")
        }
    }

    private fun refreshVoice() {
        val listening = ListenService.running
        listenBtn.text = if (listening) "⏹ وقّف الاستماع" else "👂 شغّل الاستماع"
        listenBtn.setBackgroundColor(Color.parseColor(if (listening) "#C62828" else "#00695C"))
        listenBtn.setTextColor(Color.WHITE)
        val on = Speaker.enabled(this)
        voiceToggle.text = if (on) "🔊 المساعد بيحكي: شغّال" else "🔇 المساعد بيحكي: طافي"
        val male = Speaker.isMale(this)
        maleBtn.setBackgroundColor(Color.parseColor(if (male) "#1565C0" else "#424242"))
        femaleBtn.setBackgroundColor(Color.parseColor(if (!male) "#AD1457" else "#424242"))
        maleBtn.setTextColor(Color.WHITE); femaleBtn.setTextColor(Color.WHITE)
    }

    private fun testVoice() {
        val msg = if (Speaker.isMale(this)) "أهلين، أنا مساعدك. شو بدك أعمل؟" else "أهلين، أنا مساعدتك. شو بدك أعمل؟"
        Speaker.say(this, msg, force = true)
    }

    private fun pickVoice() {
        Speaker.init(this) {
            runOnUiThread {
                val voices = Speaker.arabicVoices()
                if (voices.isEmpty()) {
                    AlertDialog.Builder(this)
                        .setMessage("ما في أصوات عربية مثبتة.\n\nنزّلها من: الإعدادات ▸ الإدارة العامة ▸ تحويل النص إلى كلام ▸ ⚙️ ▸ تثبيت بيانات الصوت ▸ العربية.")
                        .setPositiveButton("فتح الإعدادات") { _, _ ->
                            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { }
                        }
                        .setNegativeButton("لاحقاً", null).show()
                    return@runOnUiThread
                }
                val male = Speaker.isMale(this)
                AlertDialog.Builder(this)
                    .setTitle(if (male) "اختار الصوت الذكوري" else "اختار الصوت الأنثوي")
                    .setItems(voices.mapIndexed { i, v -> Speaker.voiceLabel(v, i) }.toTypedArray()) { _, i ->
                        Speaker.saveVoice(this, male, voices[i].name)
                        testVoice()
                    }
                    .show()
            }
        }
    }

    private fun refresh() {
        val on = AgentService.instance != null
        accessStatus.text = if (on) "✅ المساعد مفعّل" else
            "⚠️ المساعد مو مفعّل: بيلزم لإرسال واتساب لحاله ولفتح الأقسام. فعّله من إمكانية الوصول ▸ التطبيقات المثبتة ▸ مساعد صح صح"
        accessStatus.setTextColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#E65100"))

        cmdBox.removeAllViews()
        val cmds = Store.commands(this)
        if (cmds.isEmpty()) cmdBox.addView(text("ما في أوامر لسا، اضغط «➕ أمر جديد»"))
        cmds.forEach { cmd ->
            cmdBox.addView(text("«${cmd.name}»").apply {
                setTypeface(typeface, Typeface.BOLD); textSize = 18f; setPadding(0, 24, 0, 0)
            })
            cmdBox.addView(text(cmd.describe()).apply { textSize = 14f })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(smallButton("▶ شغّل") { show(Executor.run(this, cmd)) })
            row.addView(smallButton("⏰ جدولة") { schedule(cmd) })
            row.addView(smallButton("🗑 حذف") {
                AlertDialog.Builder(this).setMessage("تحذف «${cmd.name}»؟")
                    .setPositiveButton("حذف") { _, _ -> Store.removeCommand(this, cmd.id); refresh() }
                    .setNegativeButton("لا", null).show()
            })
            cmdBox.addView(row)
        }

        taskBox.removeAllViews()
        val tasks = Store.tasks(this)
        if (tasks.isEmpty()) taskBox.addView(text("ما في شي مجدول"))
        tasks.forEach { t ->
            val name = Store.findCommand(this, t.cmdId)?.name ?: "؟"
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                text("%02d:%02d %s: «%s»".format(t.hour, t.minute, if (t.daily) "كل يوم" else "مرة وحدة", name)),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener { Scheduler.cancel(this@AssistantActivity, t.id); Store.removeTask(this@AssistantActivity, t.id); refresh() }
            })
            taskBox.addView(row)
        }
    }

    private fun show(msg: String) {
        result.text = msg
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        Speaker.say(this, msg)
    }

    // ------------------------------------------------------------ voice
    private fun listen() {
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Voice.intent(), REQ_VOICE)
        } catch (_: ActivityNotFoundException) {
            show("ما في خدمة تعرّف على الصوت بالجوال. نزّل تطبيق Google من المتجر")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_VOICE -> show(Voice.handle(this, data))
            REQ_VIDEO -> {
                val uri = data?.data ?: return
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) { }
                val title = fileName(uri)
                askName(CmdType.VIDEO_FILE, uri.toString(), title, "", "شغل $title")
            }
        }
    }

    private fun fileName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0).substringBeforeLast('.')
        }
        return "الفيديو"
    }

    // ------------------------------------------------- new command flow
    private fun newCommand() {
        val types = CmdType.values()
        AlertDialog.Builder(this)
            .setTitle("شو بدك يعمل الأمر؟")
            .setItems(types.map { it.label }.toTypedArray()) { _, i -> askParams(types[i]) }
            .show()
    }

    private fun askParams(type: CmdType) {
        when (type) {
            CmdType.OPEN_APP -> pickApp { label, pkg ->
                askName(type, pkg, label, "", "افتح $label")
            }
            CmdType.APP_PAGE -> pickApp { label, pkg ->
                ask("اسم القسم متل ما هو مكتوب بالتطبيق", "التنزيلات") { section ->
                    askName(type, pkg, label, section, "$label $section")
                }
            }
            CmdType.APP_SEARCH -> pickApp { label, pkg ->
                ask(
                    "بحث احتياطي (اختياري)\n\nلما تقول «$label صفحة ٤٥ تمرين ٣» بيبحث عن «صفحة ٤٥ تمرين ٣». إذا ما قلت شي بعد الاسم، بيبحث عن اللي بتكتبه هون.",
                    "", allowEmpty = true
                ) { q -> askName(type, pkg, label, q, label) }
            }
            CmdType.CHAT_TYPE -> ask(
                "الصق رابط المحادثة (اختياري)\n\nمن كلود: افتح المحادثة ▸ ⋮ أو مشاركة ▸ نسخ الرابط. إذا تركته فاضي بيفتح كلود على محادثة جديدة.",
                "", allowEmpty = true
            ) { link ->
                ask(
                    "رسالة احتياطية (اختياري)\n\nلما تقول «اسأل كلود شو الطقس» بيكتب «شو الطقس». إذا ما قلت شي بعد الاسم، بيكتب اللي هون.",
                    "", allowEmpty = true
                ) { msg -> askName(type, link, "Claude", msg, "اسأل كلود") }
            }
            CmdType.YT_PLAYLIST -> ask(
                "الصق رابط البلاي ليست\n(من يوتيوب: افتح البلاي ليست ▸ مشاركة ▸ نسخ الرابط)", ""
            ) { link -> askName(type, link, "", "", "شغل البلاي ليست") }
            CmdType.YT_PLAY -> ask("شو بدك يشغّل على يوتيوب؟", "") { q ->
                askName(type, q, "", "", "شغل $q")
            }
            CmdType.WA_MSG -> askTwo(
                "لمين؟ الاسم متل ما هو بواتساب (شخص أو مجموعة)، أو الرقم مع رمز البلد مثل 9639xxxxxxxx",
                "نص الرسالة"
            ) { to, msg -> askName(type, to, msg, "", "ابعت ل$to") }
            CmdType.WEB_SEARCH -> ask("شو بدك يبحث بغوغل؟", "") { q ->
                askName(type, q, "", "", "ابحث $q")
            }
            CmdType.ALARM -> TimePickerDialog(this, { _, h, m ->
                val t = "%02d:%02d".format(h, m)
                askName(type, t, "", "", "منبه الصبح")
            }, 7, 0, true).show()
            CmdType.VIDEO_FILE -> {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("video/*")
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_VIDEO)
            }
        }
    }

    private fun askName(type: CmdType, a: String, b: String, extra: String, suggestion: String) {
        ask("سمّي الأمر: هي الجملة اللي رح تقولها لتشغّله", suggestion) { name ->
            Store.addCommand(this, name, type, a, b, extra)
            show("✅ انحفظ الأمر «$name»")
            refresh()
        }
    }

    private fun schedule(cmd: Cmd) {
        if (!Scheduler.canExact(this) && Build.VERSION.SDK_INT >= 31) {
            show("اسمح بالمنبهات الدقيقة لحتى يشتغل الأمر بوقته بالضبط، وارجع اضغط جدولة")
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            return
        }
        TimePickerDialog(this, { _, h, m ->
            AlertDialog.Builder(this)
                .setTitle("«${cmd.name}» الساعة %02d:%02d".format(h, m))
                .setPositiveButton("كل يوم") { _, _ -> addTask(cmd, h, m, true) }
                .setNegativeButton("مرة وحدة") { _, _ -> addTask(cmd, h, m, false) }
                .show()
        }, 16, 0, true).show()
    }

    private fun addTask(cmd: Cmd, h: Int, m: Int, daily: Boolean) {
        val t = Store.addTask(this, cmd.id, h, m, daily)
        Scheduler.schedule(this, t)
        show("⏰ انجدول «${cmd.name}» الساعة %02d:%02d".format(h, m))
        refresh()
    }

    // ---------------------------------------------------------- dialogs
    private fun pickApp(onPick: (String, String) -> Unit) {
        val apps = Parser.launcherApps(this)
        AlertDialog.Builder(this)
            .setTitle("اختار التطبيق")
            .setItems(apps.map { it.first }.toTypedArray()) { _, i -> onPick(apps[i].first, apps[i].second) }
            .show()
    }

    private fun ask(question: String, default: String, allowEmpty: Boolean = false, onOk: (String) -> Unit) {
        val field = EditText(this).apply { setText(default); setSelection(default.length) }
        AlertDialog.Builder(this)
            .setMessage(question)
            .setView(field)
            .setPositiveButton("تمام") { _, _ ->
                val v = field.text.toString().trim()
                if (v.isEmpty() && !allowEmpty) show("ما كتبت شي") else onOk(v)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun askTwo(q1: String, q2: String, onOk: (String, String) -> Unit) {
        val f1 = EditText(this).apply { hint = q1 }
        val f2 = EditText(this).apply { hint = q2 }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 10)
            addView(text(q1)); addView(f1); addView(text(q2)); addView(f2)
        }
        AlertDialog.Builder(this)
            .setView(box)
            .setPositiveButton("تمام") { _, _ ->
                val a = f1.text.toString().trim()
                val b = f2.text.toString().trim()
                if (a.isEmpty() || b.isEmpty()) show("لازم تعبّي الخانتين") else onOk(a, b)
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // --------------------------------------------------------- UI bits
    private fun title(s: String, size: Float) = TextView(this).apply {
        text = s; textSize = size; setTypeface(typeface, Typeface.BOLD); setPadding(0, 40, 0, 12)
    }

    private fun text(s: String) = TextView(this).apply { text = s; textSize = 16f }

    private fun button(s: String, color: String? = null, size: Float = 17f, onClick: (View) -> Unit) =
        Button(this).apply {
            text = s
            textSize = size
            if (color != null) { setBackgroundColor(Color.parseColor(color)); setTextColor(Color.WHITE) }
            setOnClickListener(onClick)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 12 }
        }

    private fun smallButton(s: String, onClick: (View) -> Unit) = Button(this).apply {
        text = s
        textSize = 14f
        setOnClickListener(onClick)
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    }
}
