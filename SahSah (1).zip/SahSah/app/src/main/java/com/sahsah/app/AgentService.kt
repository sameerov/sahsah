package com.sahsah.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Helper that presses buttons inside other apps for the fixed commands:
 * WhatsApp send, YouTube "play all", and opening a section such as Downloads.
 * No AI and no internet: it only looks for specific buttons by their name.
 */
class AgentService : AccessibilityService() {

    companion object {
        var instance: AgentService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ------------------------------------------------------------ routines

    fun pressWhatsAppSend() = async {
        val send = waitFor(12_000) { findSend() } ?: return@async "❌ ما لقيت زر الإرسال بواتساب"
        click(send)
        "✅ انبعتت الرسالة"
    }

    fun whatsAppSendByName(name: String, text: String) = async {
        Thread.sleep(1500)
        val search = waitFor(10_000) {
            byId("menuitem_search") ?: byId("my_search_bar") ?: byId("search_bar")
                ?: byDesc(listOf("search", "بحث"))
        } ?: return@async "❌ ما لقيت زر البحث بواتساب"
        click(search)
        Thread.sleep(1000)

        val input = waitFor(5000) { byId("search_input") ?: byId("search_src_text") ?: firstEditable() }
            ?: return@async "❌ ما لقيت خانة البحث"
        setText(input, name)
        Thread.sleep(2000)

        val result = waitFor(6000) { findChatResult(name) }
            ?: return@async "❌ ما لقيت محادثة باسم «$name»، تأكد إنه الاسم متل ما هو بواتساب"
        click(result)
        Thread.sleep(1500)

        val entry = waitFor(6000) { byId("entry") } ?: return@async "❌ ما انفتحت محادثة «$name»"
        setText(entry, text)
        Thread.sleep(800)

        val send = waitFor(5000) { findSend() } ?: return@async "❌ ما لقيت زر الإرسال"
        click(send)
        "✅ انبعتت لـ «$name»"
    }

    fun tapPlayAll() = async {
        val btn = waitFor(9000) { byText(listOf("play all", "تشغيل الكل", "تشغيل الكلّ", "تشغيل الجميع")) }
            ?: return@async "▶ انفتحت البلاي ليست"
        click(btn)
        "▶ عم تشتغل البلاي ليست"
    }

    fun tapFirstVideo() = async {
        Thread.sleep(4000)
        val video = waitFor(6000) {
            nodes().firstOrNull { n ->
                val d = n.contentDescription?.toString() ?: ""
                n.isClickable && (d.contains("play video") || d.contains("تشغيل الفيديو") || d.contains(" - "))
            }
        } ?: return@async "🔎 فتحت النتائج، اختار الفيديو"
        click(video)
        "▶ عم يشغّل أول فيديو"
    }

    fun tapSection(section: String) = async {
        val words = synonyms(section)
        Thread.sleep(1500)
        val target = waitFor(12_000) { byText(words) ?: byDesc(words) }
            ?: return@async "❌ ما لقيت «$section» بالتطبيق"
        click(target)
        "✅ فتحت «$section»"
    }

    fun searchInApp(query: String) = async {
        Thread.sleep(2500)
        val searchWords = listOf("search", "بحث", "ابحث", "إبحث", "البحث")
        // a search box that is already on screen, or a search button to open it
        var box = waitFor(12_000) {
            nodes().firstOrNull { it.isEditable && it.isVisibleToUser }
                ?: nodes().firstOrNull { n ->
                    n.isVisibleToUser && (n.viewIdResourceName?.lowercase()?.contains("search") == true ||
                        searchWords.any { w ->
                            n.contentDescription?.toString()?.lowercase()?.contains(w) == true ||
                                n.text?.toString()?.lowercase()?.trim() == w
                        })
                }
        } ?: return@async "❌ ما لقيت خانة البحث بالتطبيق"
        if (!box.isEditable) {
            click(box)
            Thread.sleep(1200)
            box = waitFor(5000) { firstEditable() } ?: return@async "❌ ما انفتحت خانة البحث"
        }
        setText(box, query)
        Thread.sleep(600)
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            box.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        "🔎 بحثت عن «$query»"
    }

    fun typeAndSend(text: String) = async {
        Thread.sleep(2500)
        val box = waitFor(15_000) { firstEditable() } ?: return@async "❌ ما لقيت خانة الكتابة"
        click(box)
        Thread.sleep(500)
        setText(box, text)
        Thread.sleep(1000)
        val send = waitFor(5000) { byDesc(listOf("send message", "send", "إرسال", "ارسال")) ?: byId("send") }
            ?: return@async "⚠️ كتبت الرسالة بس ما لقيت زر الإرسال"
        click(send)
        "✅ انبعتت"
    }

    private fun synonyms(section: String): List<String> {
        val s = Parser.norm(section)
        val list = mutableListOf(section.lowercase())
        if (s.contains("تنزيل") || s.contains("تحميل") || s.contains("download")) {
            list += listOf("downloads", "download", "downloaded", "تنزيلات", "التنزيلات", "تحميلات", "التحميلات", "تنزيل", "تحميل")
        }
        return list
    }

    // -------------------------------------------------------------- helpers

    private fun async(block: () -> String) {
        if (busy) { toast("في أمر شغّال، استنى شوي"); return }
        busy = true
        Thread {
            val r = try { block() } catch (e: Exception) { "❌ ${e.message}" }
            busy = false
            Store.setLast(this, r)
            toast(r)
            Speaker.say(this, r)
        }.start()
    }

    private fun <T> waitFor(ms: Long, find: () -> T?): T? {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            try { find()?.let { return it } } catch (_: Exception) { }
            Thread.sleep(500)
        }
        return null
    }

    private fun nodes(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size > 800) return
            out.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return out
    }

    private fun byId(suffix: String) =
        nodes().firstOrNull { it.viewIdResourceName?.endsWith(":id/$suffix") == true && it.isVisibleToUser }

    private fun byDesc(words: List<String>) = nodes().firstOrNull { n ->
        val d = n.contentDescription?.toString()?.lowercase()?.trim() ?: return@firstOrNull false
        n.isVisibleToUser && words.any { d == it || d.contains(it) }
    }

    private fun byText(words: List<String>) = nodes().firstOrNull { n ->
        val t = n.text?.toString()?.lowercase()?.trim() ?: return@firstOrNull false
        n.isVisibleToUser && words.any { t == it }
    } ?: nodes().firstOrNull { n ->
        val t = n.text?.toString()?.lowercase()?.trim() ?: return@firstOrNull false
        n.isVisibleToUser && t.length < 40 && words.any { t.contains(it) }
    }

    private fun firstEditable() = nodes().firstOrNull { it.isEditable && it.isVisibleToUser }

    private fun findSend() = byId("send") ?: byDesc(listOf("send", "إرسال", "ارسال"))

    private fun findChatResult(name: String): AccessibilityNodeInfo? {
        val n = name.lowercase().trim()
        val candidates = nodes().filter {
            it.isVisibleToUser && !it.isEditable && it.viewIdResourceName?.endsWith("search_input") != true
        }
        return candidates.firstOrNull { it.text?.toString()?.lowercase()?.trim() == n }
            ?: candidates.firstOrNull { it.text?.toString()?.lowercase()?.contains(n) == true }
    }

    private fun click(node: AccessibilityNodeInfo) {
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
        val r = Rect()
        node.getBoundsInScreen(r)
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        dispatchGesture(
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(),
            null, null
        )
    }

    private fun setText(node: AccessibilityNodeInfo, text: String) {
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun toast(msg: String) = main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
}
