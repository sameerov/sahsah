package com.sahsah.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice as TtsVoice
import java.util.Locale

/**
 * The assistant's voice, using the phone's built-in text-to-speech (works offline).
 * Two styles: young male (slightly lower, a bit faster) and soft female (slightly higher, a bit slower).
 */
object Speaker {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val pending = mutableListOf<String>()

    private fun prefs(c: Context) = c.getSharedPreferences("voice", Context.MODE_PRIVATE)
    fun enabled(c: Context) = prefs(c).getBoolean("on", true)
    fun setEnabled(c: Context, on: Boolean) = prefs(c).edit().putBoolean("on", on).apply()
    fun isMale(c: Context) = prefs(c).getString("gender", "male") == "male"
    fun setMale(c: Context, male: Boolean) =
        prefs(c).edit().putString("gender", if (male) "male" else "female").apply()
    private fun savedVoice(c: Context, male: Boolean) = prefs(c).getString(if (male) "v_male" else "v_female", null)
    fun saveVoice(c: Context, male: Boolean, name: String) =
        prefs(c).edit().putString(if (male) "v_male" else "v_female", name).apply()

    fun init(c: Context, onReady: (() -> Unit)? = null) {
        val app = c.applicationContext
        if (tts != null) { if (ready) onReady?.invoke(); return }
        tts = TextToSpeech(app) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                apply(app)
                synchronized(pending) { pending.forEach { speakNow(it) }; pending.clear() }
                onReady?.invoke()
            }
        }
    }

    /** Speaks a result message (emojis removed). Does nothing if speech is turned off. */
    fun say(c: Context, text: String, force: Boolean = false) {
        if (!force && !enabled(c)) return
        val clean = clean(text)
        if (clean.isBlank()) return
        init(c)
        if (ready) { apply(c.applicationContext); speakNow(clean) }
        else synchronized(pending) { pending.add(clean) }
    }

    private fun speakNow(s: String) {
        tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "sahsah")
    }

    private fun clean(s: String) = s
        .replace(Regex("[^\\p{L}\\p{N}\\s،,.:؟?!]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    /** Arabic voices installed on the phone. */
    fun arabicVoices(): List<TtsVoice> =
        tts?.voices?.filter { it.locale.language == "ar" }?.sortedBy { it.name } ?: emptyList()

    fun voiceLabel(v: TtsVoice, index: Int): String {
        val guess = when (genderOf(v)) { true -> "👨 "; false -> "👩 "; null -> "" }
        val net = if (v.isNetworkConnectionRequired) " (بدها نت)" else ""
        return "${guess}صوت ${index + 1} (${v.locale.country.ifBlank { "عربي" }})$net"
    }

    /** Best guess from the voice name: true = male, false = female, null = unknown. */
    private fun genderOf(v: TtsVoice): Boolean? {
        val n = v.name.lowercase()
        return when {
            n.contains("female") || n.contains("smtf") || Regex("[-_]f\\d").containsMatchIn(n) -> false
            n.contains("male") || n.contains("smtm") || Regex("[-_]m\\d").containsMatchIn(n) -> true
            else -> null
        }
    }

    private fun apply(c: Context) {
        val t = tts ?: return
        val male = isMale(c)
        val voices = arabicVoices()
        val chosen = voices.firstOrNull { it.name == savedVoice(c, male) }
            ?: voices.filter { !it.isNetworkConnectionRequired }.firstOrNull { genderOf(it) == male }
            ?: voices.firstOrNull { genderOf(it) == male }
            ?: voices.firstOrNull { !it.isNetworkConnectionRequired }
            ?: voices.firstOrNull()
        if (chosen != null) t.voice = chosen else t.language = Locale("ar")
        // Shape the tone so the two styles sound different even with the same voice
        t.setPitch(if (male) 0.88f else 1.18f)
        t.setSpeechRate(if (male) 1.05f else 0.93f)
    }
}
