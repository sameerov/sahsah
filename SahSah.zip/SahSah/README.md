# صح صح

Android app with one big On/Off button. While ON:
- Replies **صح صح** to WhatsApp private chats (not groups), at most once per chat every 30 seconds.
- Rejects phone calls and declines WhatsApp calls.
- Turns on Do Not Disturb (alarms still ring) and clears incoming notifications.

While OFF it does nothing, and your previous Do Not Disturb mode is restored.

## Build the APK

**Option A – Android Studio (computer):** Open this folder → wait for sync → Build ▸ Build APK(s). The file appears in `app/build/outputs/apk/debug/`.

**Option B – GitHub (no Android Studio):** Create a new GitHub repository, upload all these files (keep the folders), then open the **Actions** tab → *Build APK* → when it finishes, download **SahSah-apk**.

## Install and first run
1. Copy `app-debug.apk` to the phone and open it (allow "Install unknown apps").
2. Open **صح صح** and press **تشغيل**. It will take you to three permission screens: notification access, Do Not Disturb access, and phone calls. Allow each, come back, and press **تشغيل** again.
3. On Android 13+, if notification access is greyed out: Settings ▸ Apps ▸ صح صح ▸ ⋮ ▸ *Allow restricted settings*.
4. Keep WhatsApp notifications ON in WhatsApp's settings – the app replies through them.

## Limits
- Some phones (Xiaomi, Huawei, Oppo, Samsung) kill background services: set battery to *Unrestricted* for صح صح.
- If WhatsApp shows only a summary notification for a chat (e.g. chat muted), that chat won't get a reply.
- Declining WhatsApp calls depends on the "Decline" button text; on most phones it works, if not, the call is still silenced by Do Not Disturb.
