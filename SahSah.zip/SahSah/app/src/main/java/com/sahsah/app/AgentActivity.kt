package com.sahsah.app

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class AgentActivity : Activity() {

    private lateinit var accessStatus: TextView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var goalField: EditText
    private lateinit var tasksBox: LinearLayout
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 80)
        }

        col.addView(title("🤖 المساعد الذكي", 30f))

        // 1. accessibility
        col.addView(title("١. التفعيل", 20f))
        accessStatus = text("")
        col.addView(accessStatus)
        col.addView(button("فتح إعدادات إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        // 2. API key
        col.addView(title("٢. مفتاح Gemini", 20f))
        keyField = field("الصق مفتاح API هون").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Store.apiKey(this@AgentActivity))
        }
        col.addView(keyField)
        modelField = field("اسم الموديل").apply { setText(Store.model(this@AgentActivity)) }
        col.addView(modelField)
        col.addView(button("حفظ") { saveSettings(); toast("انحفظ") })

        // 3. task
        col.addView(title("٣. المهمة", 20f))
        goalField = field("مثلاً: افتح يوتيوب وابحث عن أخبار اليوم وشغّل أول فيديو").apply {
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        col.addView(goalField)
        col.addView(button("▶ نفّذ الآن", "#2E7D32") { runNow() })
        col.addView(button("⏰ جدولة بوقت معيّن", "#1565C0") { pickTime() })
        col.addView(button("⏹ أوقف المهمة الحالية", "#C62828") {
            AgentService.stopRequested = true
            toast("رح توقف بعد الخطوة الحالية")
        })

        // 4. scheduled list
        col.addView(title("المهام المجدولة", 20f))
        tasksBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tasksBox)

        // 5. log
        col.addView(title("سجل آخر مهمة", 20f))
        logView = text("").apply { typeface = Typeface.MONOSPACE; textSize = 13f }
        col.addView(logView)
        col.addView(button("تحديث السجل") { refresh() })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val on = AgentService.instance != null
        accessStatus.text = if (on) "✅ المساعد مفعّل" else
            "❌ مو مفعّل: افتح الإعدادات ▸ التطبيقات المثبتة ▸ مساعد صح صح ▸ تشغيل"
        accessStatus.setTextColor(if (on) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))

        tasksBox.removeAllViews()
        val tasks = Store.tasks(this)
        if (tasks.isEmpty()) tasksBox.addView(text("ما في مهام مجدولة"))
        tasks.forEach { t ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 10, 0, 10)
            }
            val label = text(
                "%02d:%02d %s\n%s".format(t.hour, t.minute, if (t.daily) "يومياً" else "مرة وحدة", t.goal)
            )
            row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    Scheduler.cancel(this@AgentActivity, t.id)
                    Store.removeTask(this@AgentActivity, t.id)
                    refresh()
                }
            })
            tasksBox.addView(row)
        }

        logView.text = Store.log(this).ifBlank { "(فاضي)" }
    }

    private fun saveSettings() {
        Store.saveSettings(this, keyField.text.toString(), modelField.text.toString())
    }

    private fun ready(): Boolean {
        saveSettings()
        if (goalField.text.isBlank()) { toast("اكتب المهمة أولاً"); return false }
        if (Store.apiKey(this).isBlank()) { toast("حط مفتاح Gemini أولاً"); return false }
        return true
    }

    private fun runNow() {
        if (!ready()) return
        val agent = AgentService.instance
        if (agent == null) { toast("فعّل المساعد من إمكانية الوصول أولاً"); return }
        agent.startTask(goalField.text.toString().trim())
    }

    private fun pickTime() {
        if (!ready()) return
        if (!Scheduler.canExact(this) && Build.VERSION.SDK_INT >= 31) {
            toast("اسمح بالمنبهات الدقيقة لحتى تشتغل المهمة بوقتها بالضبط")
            startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
            )
            return
        }
        TimePickerDialog(this, { _, h, m ->
            AlertDialog.Builder(this)
                .setTitle("تتكرر كل يوم؟")
                .setPositiveButton("يومياً") { _, _ -> addTask(h, m, true) }
                .setNegativeButton("مرة وحدة") { _, _ -> addTask(h, m, false) }
                .show()
        }, 16, 0, true).show()
    }

    private fun addTask(h: Int, m: Int, daily: Boolean) {
        val t = Store.addTask(this, goalField.text.toString().trim(), h, m, daily)
        Scheduler.schedule(this, t)
        toast("انجدولت الساعة %02d:%02d".format(h, m))
        goalField.setText("")
        refresh()
    }

    // ---- small UI helpers ----
    private fun title(s: String, size: Float) = TextView(this).apply {
        text = s; textSize = size; setTypeface(typeface, Typeface.BOLD); setPadding(0, 40, 0, 12)
    }

    private fun text(s: String) = TextView(this).apply { text = s; textSize = 16f }

    private fun field(hint: String) = EditText(this).apply { this.hint = hint; textSize = 16f }

    private fun button(s: String, color: String? = null, onClick: (View) -> Unit) = Button(this).apply {
        text = s
        textSize = 17f
        if (color != null) { setBackgroundColor(Color.parseColor(color)); setTextColor(Color.WHITE) }
        setOnClickListener(onClick)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 12 }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
