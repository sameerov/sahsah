package com.sahsah.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/** The «صح صح» button in the quick-settings panel, like the VPN button. */
class ModeTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        when {
            State.isOn(this) -> State.turnOff(this)
            State.ready(this) -> State.turnOn(this)
            else -> {
                Toast.makeText(this, "افتح التطبيق مرة لتعطيه الصلاحيات", Toast.LENGTH_LONG).show()
                openApp()
            }
        }
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val on = State.isOn(this)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "صح صح"
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = if (on) "شغّال" else "طافي"
        tile.updateTile()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
