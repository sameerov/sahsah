package com.sahsah.app

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import android.service.quicksettings.TileService
import org.json.JSONArray
import org.json.JSONObject

/** Someone who is never auto-replied to or blocked. */
data class Person(val name: String, val number: String = "")

/** Settings + switching the mode on and off (used by the app screen and the quick-settings button). */
object State {
    private fun prefs(c: Context) = c.getSharedPreferences("sahsah", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- reply text
    fun replyText(c: Context): String = (prefs(c).getString("reply", "") ?: "").ifBlank { "صح صح" }
    fun setReplyText(c: Context, text: String) = prefs(c).edit().putString("reply", text.trim()).apply()

    // ---------------------------------------------------------------- exceptions
    fun exceptions(c: Context): List<Person> {
        val arr = JSONArray(prefs(c).getString("exceptions", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Person(o.getString("name"), o.optString("number"))
        }
    }

    private fun saveExceptions(c: Context, list: List<Person>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("name", it.name).put("number", it.number)) }
        prefs(c).edit().putString("exceptions", arr.toString()).apply()
    }

    fun addException(c: Context, p: Person) {
        val list = exceptions(c).filterNot { norm(it.name) == norm(p.name) }
        saveExceptions(c, list + p)
    }

    fun removeException(c: Context, p: Person) = saveExceptions(c, exceptions(c).filterNot { it == p })

    private fun norm(s: String) = s.lowercase()
        .replace(Regex("[ً-ْـ]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
        .replace('ى', 'ي').replace('ة', 'ه')
        .replace(Regex("\\s+"), " ").trim()

    private fun lastDigits(n: String) = n.filter { it.isDigit() }.takeLast(8)

    /** WhatsApp shows the contact or group name as the notification title. */
    fun isExceptedName(c: Context, vararg titles: String?): Boolean {
        val t = titles.filterNotNull().map { norm(it) }.filter { it.isNotEmpty() }
        if (t.isEmpty()) return false
        return exceptions(c).any { p ->
            val n = norm(p.name)
            n.isNotEmpty() && t.any { it == n || it.startsWith("$n ") || it.startsWith("$n:") || it.contains(n) }
        }
    }

    fun isExceptedNumber(c: Context, number: String?): Boolean {
        val d = lastDigits(number ?: return false)
        if (d.length < 6) return false
        return exceptions(c).any { lastDigits(it.number) == d }
    }

    // ---------------------------------------------------------------- on / off
    fun isOn(c: Context): Boolean = prefs(c).getBoolean("on", false)

    fun hasListener(c: Context): Boolean =
        (Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: "").contains(c.packageName)

    fun hasDnd(c: Context): Boolean = c.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    val PHONE_PERMS = arrayOf(
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.READ_CALL_LOG // to see the caller's number (for exceptions)
    )

    fun hasPhone(c: Context): Boolean =
        PHONE_PERMS.all { c.checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    fun ready(c: Context) = hasListener(c) && hasDnd(c) && hasPhone(c)

    fun turnOn(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        prefs(c).edit().putInt("prev_filter", nm.currentInterruptionFilter).apply()
        try { nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS) } catch (_: Exception) { }
        prefs(c).edit().putBoolean("on", true).apply()
        updateTile(c)
    }

    fun turnOff(c: Context) {
        prefs(c).edit().putBoolean("on", false).apply()
        if (hasDnd(c)) {
            val f = prefs(c).getInt("prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
            try {
                c.getSystemService(NotificationManager::class.java)
                    .setInterruptionFilter(if (f in 1..4) f else NotificationManager.INTERRUPTION_FILTER_ALL)
            } catch (_: Exception) { }
        }
        updateTile(c)
    }

    private fun updateTile(c: Context) {
        try { TileService.requestListeningState(c, ComponentName(c, ModeTile::class.java)) } catch (_: Exception) { }
    }
}
