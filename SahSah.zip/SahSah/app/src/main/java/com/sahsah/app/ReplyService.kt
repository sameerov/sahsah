package com.sahsah.app

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telecom.TelecomManager
import android.telephony.TelephonyManager

/**
 * While the mode is ON:
 *  - replies with the chosen sentence to WhatsApp private chats
 *  - declines WhatsApp calls and rejects phone calls
 *  - removes incoming notifications
 * People in the exceptions list are left alone: no reply, and their calls and messages still ring.
 */
class ReplyService : NotificationListenerService() {

    companion object {
        private val WHATSAPP = setOf("com.whatsapp", "com.whatsapp.w4b")
        private const val COOLDOWN_MS = 30_000L // one reply per chat every 30s
    }

    private val main = Handler(Looper.getMainLooper())
    private val lastReply = HashMap<String, Long>()
    private var receiverRegistered = false

    // ---------------------------------------------------------------- phone calls
    private var decided = false
    private var ringtone: Ringtone? = null
    private var whatsappCallKey: String? = null

    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!State.isOn(c)) return
            when (i.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    if (decided) return
                    @Suppress("DEPRECATION")
                    val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
                    if (number != null) {
                        decideCall(number)
                    } else {
                        // Android often sends the number in a second message; wait for it briefly
                        main.postDelayed({ if (!decided) decideCall(null) }, 900)
                    }
                }
                else -> { // answered or ended
                    decided = false
                    main.removeCallbacksAndMessages(null)
                    stopRinging()
                }
            }
        }
    }

    private fun decideCall(number: String?) {
        decided = true
        if (State.isExceptedNumber(this, number)) startRinging() else endPhoneCall()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (!receiverRegistered) {
            val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(callReceiver, filter, Context.RECEIVER_EXPORTED)
            else registerReceiver(callReceiver, filter)
            receiverRegistered = true
        }
    }

    override fun onListenerDisconnected() {
        if (receiverRegistered) {
            try { unregisterReceiver(callReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        stopRinging()
        super.onListenerDisconnected()
    }

    // ---------------------------------------------------------------- notifications
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!State.isOn(this) || sbn.packageName == packageName) return
        val n = sbn.notification
        val extras = n.extras
        val isWhatsApp = sbn.packageName in WHATSAPP

        if (isWhatsApp) {
            val excepted = State.isExceptedName(
                this,
                extras.getCharSequence(Notification.EXTRA_TITLE)?.toString(),
                extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString(),
                extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
            )
            if (excepted) {
                // Let it through and make it heard despite silent mode
                if (n.category == Notification.CATEGORY_CALL) {
                    whatsappCallKey = sbn.key
                    startRinging()
                } else if (n.flags and Notification.FLAG_GROUP_SUMMARY == 0) {
                    beep()
                }
                return
            }
            if (n.category == Notification.CATEGORY_CALL) {
                declineWhatsAppCall(n)
                return
            }
            if (n.flags and Notification.FLAG_GROUP_SUMMARY == 0) replyTo(sbn)
        }

        if (sbn.isClearable) {
            try { cancelNotification(sbn.key) } catch (_: Exception) { }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.key == whatsappCallKey) {
            whatsappCallKey = null
            stopRinging()
        }
    }

    private fun replyTo(sbn: StatusBarNotification) {
        val n = sbn.notification
        val extras = n.extras

        // Private chats only, never groups
        if (extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return

        val reply = State.replyText(this)
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.contains(reply)) return // don't answer our own reply

        val chatId = n.shortcutId ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: sbn.key
        val now = System.currentTimeMillis()
        if (now - (lastReply[chatId] ?: 0L) < COOLDOWN_MS) return

        val action = findReplyAction(n) ?: return
        val inputs = action.remoteInputs ?: return
        val results = Bundle()
        inputs.forEach { results.putCharSequence(it.resultKey, reply) }
        val intent = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
        RemoteInput.addResultsToIntent(inputs, intent, results)
        try {
            action.actionIntent.send(this, 0, intent)
            lastReply[chatId] = now
        } catch (_: PendingIntent.CanceledException) { }
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val all = (n.actions?.toList() ?: emptyList()) + Notification.WearableExtender(n).actions
        return all.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
    }

    private fun declineWhatsAppCall(n: Notification) {
        val words = listOf("decline", "reject", "رفض")
        val decline = n.actions?.firstOrNull { a ->
            val t = a.title?.toString()?.lowercase() ?: ""
            words.any { t.contains(it) }
        } ?: return
        try { decline.actionIntent.send() } catch (_: PendingIntent.CanceledException) { }
    }

    private fun endPhoneCall() {
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) return
        try {
            @Suppress("DEPRECATION")
            getSystemService(TelecomManager::class.java).endCall()
        } catch (_: Exception) { }
    }

    // ---------------------------------------------------------------- sounds for excepted people
    // Silent mode still allows alarm sounds, so these play through the alarm channel.
    private fun sound(type: Int): Ringtone? = try {
        RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(type))?.apply {
            audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        }
    } catch (_: Exception) { null }

    private fun startRinging() {
        if (ringtone?.isPlaying == true) return
        ringtone = sound(RingtoneManager.TYPE_RINGTONE)?.apply {
            if (Build.VERSION.SDK_INT >= 28) isLooping = true
            play()
        }
        main.postDelayed({ stopRinging() }, 45_000) // safety stop
    }

    private fun stopRinging() {
        try { ringtone?.stop() } catch (_: Exception) { }
        ringtone = null
    }

    private fun beep() {
        sound(RingtoneManager.TYPE_NOTIFICATION)?.play()
    }
}
