package com.sahsah.app

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telecom.TelecomManager
import android.telephony.TelephonyManager

/**
 * While the app is ON:
 *  - replies "صح صح" to WhatsApp private chats
 *  - declines WhatsApp calls and rejects phone calls
 *  - removes incoming notifications
 * While OFF it does nothing.
 */
class ReplyService : NotificationListenerService() {

    companion object {
        private val WHATSAPP = setOf("com.whatsapp", "com.whatsapp.w4b")
        private const val COOLDOWN_MS = 30_000L // one reply per chat every 30s, avoids spam loops
    }

    private val lastReply = HashMap<String, Long>()
    private var receiverRegistered = false

    // Phone calls: hang up as soon as the phone starts ringing
    private val callReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!State.isOn(c)) return
            if (i.getStringExtra(TelephonyManager.EXTRA_STATE) == TelephonyManager.EXTRA_STATE_RINGING) {
                endPhoneCall()
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (!receiverRegistered) {
            val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(callReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                registerReceiver(callReceiver, filter)
            }
            receiverRegistered = true
        }
    }

    override fun onListenerDisconnected() {
        if (receiverRegistered) {
            try { unregisterReceiver(callReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!State.isOn(this) || sbn.packageName == packageName) return
        val n = sbn.notification

        if (sbn.packageName in WHATSAPP) {
            if (n.category == Notification.CATEGORY_CALL) {
                declineWhatsAppCall(n)
                return
            }
            if (n.flags and Notification.FLAG_GROUP_SUMMARY == 0) {
                replyTo(sbn)
            }
        }

        // Block the notification
        if (sbn.isClearable) {
            try { cancelNotification(sbn.key) } catch (_: Exception) { }
        }
    }

    private fun replyTo(sbn: StatusBarNotification) {
        val n = sbn.notification
        val extras = n.extras

        // Private chats only, never groups
        if (extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return

        val reply = State.replyText(this)

        // Don't answer our own reply
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.contains(reply)) return

        val chatId = n.shortcutId
            ?: extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: sbn.key
        val now = System.currentTimeMillis()
        if (now - (lastReply[chatId] ?: 0L) < COOLDOWN_MS) return

        val action = findReplyAction(n) ?: return
        val inputs = action.remoteInputs ?: return

        val results = Bundle()
        inputs.forEach { results.putCharSequence(it.resultKey, reply) }
        val intent = Intent().addFlags(Intent.FLAG_RECEIVER_FOREGROUND)
        RemoteInput.addResultsToIntent(inputs, intent, results)

        try {
            action.actionIntent.send(this, 0, intent)
            lastReply[chatId] = now
        } catch (_: PendingIntent.CanceledException) { }
    }

    private fun findReplyAction(n: Notification): Notification.Action? {
        val all = (n.actions?.toList() ?: emptyList()) + Notification.WearableExtender(n).actions
        return all.firstOrNull { !it.remoteInputs.isNullOrEmpty() }
    }

    private fun declineWhatsAppCall(n: Notification) {
        val words = listOf("decline", "reject", "رفض")
        val decline = n.actions?.firstOrNull { a ->
            val t = a.title?.toString()?.lowercase() ?: ""
            words.any { t.contains(it) }
        } ?: return
        try { decline.actionIntent.send() } catch (_: PendingIntent.CanceledException) { }
    }

    private fun endPhoneCall() {
        if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val tm = getSystemService(TelecomManager::class.java)
            @Suppress("DEPRECATION")
            tm.endCall()
        } catch (_: Exception) { }
    }
}
