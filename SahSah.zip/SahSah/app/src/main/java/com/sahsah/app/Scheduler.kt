package com.sahsah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** Sets alarms for scheduled tasks. */
object Scheduler {
    private fun pending(c: Context, id: Int): PendingIntent {
        val i = Intent(c, TaskReceiver::class.java).putExtra("id", id)
        return PendingIntent.getBroadcast(
            c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canExact(c: Context): Boolean {
        val am = c.getSystemService(AlarmManager::class.java)
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun schedule(c: Context, t: Task) {
        val am = c.getSystemService(AlarmManager::class.java)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, t.hour)
            set(Calendar.MINUTE, t.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pi = pending(c, t.id)
        if (canExact(c)) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }

    fun cancel(c: Context, id: Int) {
        c.getSystemService(AlarmManager::class.java).cancel(pending(c, id))
    }

    fun rescheduleAll(c: Context) = Store.tasks(c).forEach { schedule(c, it) }
}

/** Fires when a task's time comes. */
class TaskReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val task = Store.findTask(c, id) ?: return
        if (task.daily) Scheduler.schedule(c, task) else Store.removeTask(c, id)

        val agent = AgentService.instance
        if (agent == null) {
            Store.appendLog(c, "❌ ما نفّذت «${task.goal}» لأن المساعد مو مفعّل بإمكانية الوصول")
        } else {
            agent.startTask(task.goal)
        }
    }
}

/** Puts the alarms back after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.rescheduleAll(c)
    }
}
