package com.sahsah.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_CONTACT = 5
    private lateinit var toggle: Button
    private lateinit var status: TextView
    private lateinit var exBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = Ui.screen(this, "صح صح", "رد تلقائي ورفض مكالمات وقت تكون مشغول")

        // ---- On / off ----
        val modeCard = Ui.card(this, "🔕 الوضع")
        status = Ui.body(this, "").apply { setPadding(0, Ui.dp(this@MainActivity, 8), 0, 0) }
        modeCard.addView(status)
        toggle = Ui.button(this, "", Ui.GREEN, 22f) { onToggle() }
        modeCard.addView(toggle)
        col.addView(modeCard)

        // ---- Reply sentence ----
        val replyCard = Ui.card(this, "💬 الجملة اللي بيبعتها")
        val replyField = Ui.field(this, "صح صح", State.replyText(this))
        replyCard.addView(replyField)
        replyCard.addView(Ui.button(this, "حفظ") {
            State.setReplyText(this, replyField.text.toString())
            replyField.setText(State.replyText(this))
            toast("انحفظ: ${State.replyText(this)}")
            refresh()
        })
        col.addView(replyCard)

        // ---- Exceptions ----
        val exCard = Ui.card(this, "⭐ الاستثناءات",
            "هدول ما بيوصلهم رد تلقائي، ومكالماتهم ورسايلهم بترن عادي حتى والوضع شغّال.")
        exBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        exCard.addView(exBox)
        exCard.addView(Ui.row(this,
            "👤 من جهات الاتصال" to { pickContact() },
            "✏️ اسم أو مجموعة" to { addByName() }
        ))
        col.addView(exCard)

        // ---- Quick settings tip ----
        col.addView(Ui.card(this, "⚡ زر بالستارة",
            "نزّل الستارة ▸ ✏️ (تعديل) ▸ لاقي «صح صح» واسحبه لفوق مع الأزرار.\n" +
            "بعدها بتشغّله وبتطفيه متل زر الـ VPN، بدون ما تفتح التطبيق."))
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------------------------------------------------------------- on / off
    private fun onToggle() {
        if (State.isOn(this)) { State.turnOff(this); refresh(); return }
        when {
            !State.hasListener(this) -> {
                toast("فعّل «صح صح» بصفحة الوصول للإشعارات وارجع")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
            !State.hasDnd(this) -> {
                toast("اسمح لـ «صح صح» بالتحكم بعدم الإزعاج وارجع")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
            !State.hasPhone(this) -> requestPermissions(State.PHONE_PERMS, 1)
            else -> { State.turnOn(this); refresh() }
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (State.hasPhone(this)) onToggle() else { toast("بدون صلاحية المكالمات ما بيقدر يرفضها"); refresh() }
    }

    private fun refresh() {
        val on = State.isOn(this)
        toggle.text = if (on) "⏹ إيقاف" else "▶ تشغيل"
        Ui.paint(toggle, if (on) Ui.RED else Ui.GREEN)
        status.text = if (on) {
            "✅ شغّال\n• بيرد بـ «${State.replyText(this)}»\n• بيرفض المكالمات\n• بيخفي الإشعارات"
        } else {
            val missing = buildList {
                if (!State.hasListener(this@MainActivity)) add("الوصول للإشعارات")
                if (!State.hasDnd(this@MainActivity)) add("التحكم بعدم الإزعاج")
                if (!State.hasPhone(this@MainActivity)) add("المكالمات")
            }
            if (missing.isEmpty()) "⏸ طافي" else "⏸ طافي\nلما تشغّله أول مرة رح يطلب: " + missing.joinToString("، ")
        }
        renderExceptions()
    }

    // ---------------------------------------------------------------- exceptions
    private fun renderExceptions() {
        exBox.removeAllViews()
        val list = State.exceptions(this)
        if (list.isEmpty()) {
            exBox.addView(Ui.muted(this, "ما في حدا مستثنى.").apply { setPadding(0, Ui.dp(context, 10), 0, 0) })
            return
        }
        list.forEach { p ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(0, Ui.dp(context, 10), 0, 0)
            }
            row.addView(
                Ui.body(this, p.name + if (p.number.isNotBlank()) "\n${p.number}" else "", 15f),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(Button(this).apply {
                text = "إزالة"; isAllCaps = false; stateListAnimator = null; textSize = 14f
                setTextColor(Ui.color(Ui.TEXT)); background = Ui.rounded(context, Ui.GREY, 10)
                setOnClickListener { State.removeException(context, p); renderExceptions() }
            })
            exBox.addView(row)
        }
    }

    private fun pickContact() {
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI), REQ_CONTACT)
        } catch (_: Exception) {
            toast("ما قدرت افتح جهات الاتصال")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CONTACT || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        try {
            contentResolver.query(uri, cols, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val name = it.getString(0) ?: ""
                    val number = it.getString(1) ?: ""
                    State.addException(this, Person(name.ifBlank { number }, number))
                    toast("⭐ انضاف: $name")
                }
            }
        } catch (_: Exception) {
            toast("ما قدرت اقرأ جهة الاتصال")
        }
        renderExceptions()
    }

    private fun addByName() {
        val field = EditText(this).apply { hint = "الاسم متل ما هو بواتساب" }
        val box = LinearLayout(this).apply {
            setPadding(Ui.dp(context, 20), Ui.dp(context, 4), Ui.dp(context, 20), 0)
            addView(field, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        AlertDialog.Builder(this)
            .setTitle("استثناء باسم")
            .setMessage("اكتب اسم الشخص أو المجموعة بالضبط متل ما بيطلع بواتساب. هيك بتنستثنى رسايله على واتساب، بس مكالماته العادية بتحتاج تضيفه من جهات الاتصال.")
            .setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val n = field.text.toString().trim()
                if (n.isNotEmpty()) { State.addException(this, Person(n)); renderExceptions() }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
