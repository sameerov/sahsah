package com.sahsah.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONObject

/**
 * The AI agent. It reads what is on the screen, asks Gemini what to do next,
 * and taps / types / scrolls until the task is done (max 30 steps).
 */
class AgentService : AccessibilityService() {

    companion object {
        var instance: AgentService? = null
        @Volatile var running = false
        @Volatile var stopRequested = false
        private const val MAX_STEPS = 30
    }

    private val main = Handler(Looper.getMainLooper())
    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startTask(goal: String) {
        if (running) {
            toast("في مهمة شغّالة هلأ")
            return
        }
        running = true
        stopRequested = false
        Thread {
            try { runTask(goal) } catch (e: Exception) {
                log("❌ خطأ: ${e.message}")
            } finally { running = false }
        }.start()
    }

    // ------------------------------------------------------------------ loop
    private fun runTask(goal: String) {
        Store.clearLog(this)
        log("المهمة: $goal")
        toast("🤖 بدأت المهمة")

        // Turn the screen on while working
        val pm = getSystemService(PowerManager::class.java)
        @Suppress("DEPRECATION")
        val wl = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "sahsah:agent"
        )
        wl.acquire(10 * 60 * 1000L)

        try {
            performGlobalAction(GLOBAL_ACTION_HOME)
            Thread.sleep(1500)

            val history = mutableListOf<String>()
            val apps = launcherApps().joinToString("، ") { it.first }

            for (step in 1..MAX_STEPS) {
                if (stopRequested) { log("⏹ أوقفت المهمة"); toast("أوقفت المهمة"); return }

                val screen = describeScreen()
                val prompt = buildPrompt(goal, apps, history, screen)

                val raw = try { Gemini.ask(this, prompt) } catch (e: Exception) {
                    log("❌ ${e.message}")
                    toast("خطأ بالاتصال بـ Gemini")
                    return
                }
                val a = try {
                    JSONObject(raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
                } catch (e: Exception) {
                    log("رد غير مفهوم: ${raw.take(150)}")
                    history.add("$step. (رد غير صالح، أعد المحاولة بصيغة JSON)")
                    continue
                }

                val action = a.optString("action")
                log("$step. $action ${a.optString("why")}")
                history.add("$step. ${a.toString().take(200)}")
                if (history.size > 12) history.removeAt(0)

                when (action) {
                    "done" -> {
                        val s = a.optString("summary", "خلصت")
                        log("✅ $s"); toast("✅ $s"); return
                    }
                    "fail" -> {
                        val r = a.optString("reason", "ما قدرت")
                        log("❌ $r"); toast("❌ $r"); return
                    }
                    else -> {
                        val result = execute(a)
                        if (result.isNotEmpty()) {
                            log("   ↳ $result")
                            history.add("   النتيجة: $result")
                        }
                    }
                }
                Thread.sleep(2500)
            }
            log("⚠️ وصلت للحد الأقصى ($MAX_STEPS خطوة) بدون ما تخلص")
            toast("ما خلصت المهمة")
        } finally {
            if (wl.isHeld) wl.release()
        }
    }

    private fun buildPrompt(goal: String, apps: String, history: List<String>, screen: String) = """
أنت مساعد يتحكم بتلفون أندرويد لينجز مهمة المستخدم خطوة بخطوة.

المهمة: $goal

التطبيقات المثبتة: $apps

الخطوات السابقة:
${if (history.isEmpty()) "(لا شيء بعد)" else history.joinToString("\n")}

الشاشة الحالية (العناصر مرقمة):
$screen

اختر خطوة واحدة فقط، وأجب بكائن JSON واحد بهذا الشكل، مع حقل "why" فيه سبب قصير:
{"action":"open_app","name":"اسم التطبيق كما في القائمة","why":"..."}
{"action":"tap","id":رقم_العنصر,"why":"..."}
{"action":"type","id":رقم_حقل_الكتابة,"text":"النص","enter":true,"why":"..."}
{"action":"scroll","direction":"down" أو "up","why":"..."}
{"action":"back","why":"..."}
{"action":"home","why":"..."}
{"action":"wait","why":"..."}
{"action":"done","summary":"ماذا أنجزت","why":"..."}
{"action":"fail","reason":"لماذا لا يمكن الإكمال","why":"..."}

قواعد:
- لا تشترِ ولا تدفع ولا ترسل رسائل ولا تحذف شيئاً إلا إذا طلبت المهمة ذلك صراحة.
- إذا بقيت الشاشة نفسها بعد 3 محاولات، جرّب طريقة أخرى أو أعد "fail".
- إذا ظهرت نافذة تسجيل دخول أو كلمة سر، أعد "fail".
- عندما تتحقق المهمة أعد "done".
""".trimIndent()

    // ---------------------------------------------------------------- screen
    private fun describeScreen(): String {
        val root = rootInActiveWindow ?: return "(لا يمكن قراءة الشاشة)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        val sb = StringBuilder("التطبيق الحالي: ${root.packageName}\n")
        walk(root, list, sb)
        nodes = list
        return if (list.isEmpty()) sb.append("(الشاشة فارغة أو لسا عم تحمّل)").toString() else sb.toString()
    }

    private fun walk(n: AccessibilityNodeInfo?, list: MutableList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (n == null || list.size >= 200) return
        if (n.isVisibleToUser) {
            val label = (n.text ?: n.contentDescription ?: n.hintText)?.toString()?.trim()?.take(80) ?: ""
            val useful = label.isNotEmpty() || n.isClickable || n.isEditable || n.isScrollable
            if (useful) {
                val idx = list.size
                list.add(n)
                val type = n.className?.toString()?.substringAfterLast('.') ?: "View"
                val flags = buildList {
                    if (n.isClickable) add("قابل للضغط")
                    if (n.isEditable) add("حقل كتابة")
                    if (n.isScrollable) add("قابل للتمرير")
                    if (n.isChecked) add("مفعّل")
                }.joinToString("، ")
                sb.append("[$idx] $type \"$label\"")
                if (flags.isNotEmpty()) sb.append(" ($flags)")
                sb.append('\n')
            }
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), list, sb)
    }

    // --------------------------------------------------------------- actions
    private fun execute(a: JSONObject): String = when (a.optString("action")) {
        "open_app" -> openApp(a.optString("name"))
        "tap" -> tap(a.optInt("id", -1))
        "type" -> type(a.optInt("id", -1), a.optString("text"), a.optBoolean("enter", false))
        "scroll" -> { swipe(a.optString("direction") != "up"); "" }
        "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "" }
        "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "" }
        "wait" -> { Thread.sleep(3000); "" }
        else -> "أمر غير معروف"
    }

    private fun launcherApps(): List<Pair<String, String>> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0).map {
            it.loadLabel(packageManager).toString() to it.activityInfo.packageName
        }.distinctBy { it.second }
    }

    private fun openApp(name: String): String {
        val q = name.trim().lowercase()
        val app = launcherApps().let { all ->
            all.firstOrNull { it.first.lowercase() == q || it.second == q }
                ?: all.firstOrNull { it.first.lowercase().contains(q) || q.contains(it.first.lowercase()) }
        } ?: return "ما لقيت تطبيق اسمه $name"
        val launch = packageManager.getLaunchIntentForPackage(app.second) ?: return "ما قدرت افتح ${app.first}"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        Thread.sleep(2000)
        return "فتحت ${app.first}"
    }

    private fun tap(id: Int): String {
        val node = nodes.getOrNull(id) ?: return "رقم عنصر غير موجود"
        var n: AccessibilityNodeInfo? = node
        while (n != null && !n.isClickable) n = n.parent
        if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return ""
        val r = Rect()
        node.getBoundsInScreen(r)
        gesture(r.exactCenterX(), r.exactCenterY(), r.exactCenterX(), r.exactCenterY(), 60)
        return ""
    }

    private fun type(id: Int, text: String, enter: Boolean): String {
        var node = nodes.getOrNull(id) ?: return "رقم عنصر غير موجود"
        if (!node.isEditable) {
            node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Thread.sleep(800)
            node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "العنصر مو حقل كتابة"
        }
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (enter && android.os.Build.VERSION.SDK_INT >= 30) {
            Thread.sleep(400)
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return if (ok) "" else "ما قدرت اكتب"
    }

    private fun swipe(contentDown: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val top = m.heightPixels * 0.3f
        val bottom = m.heightPixels * 0.75f
        if (contentDown) gesture(x, bottom, x, top, 400) else gesture(x, top, x, bottom, 400)
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        dispatchGesture(g, null, null)
        Thread.sleep(ms + 200)
    }

    // ----------------------------------------------------------------- utils
    private fun log(line: String) = Store.appendLog(this, line)
    private fun toast(msg: String) = main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
}
