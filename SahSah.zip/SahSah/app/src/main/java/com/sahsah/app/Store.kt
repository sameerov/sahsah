package com.sahsah.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Task(val id: Int, val goal: String, val hour: Int, val minute: Int, val daily: Boolean)

/** Saves the API key, model, scheduled tasks and the last run's log. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)

    fun apiKey(c: Context) = p(c).getString("api_key", "") ?: ""
    fun model(c: Context) = (p(c).getString("model", "") ?: "").ifBlank { "gemini-flash-latest" }
    fun saveSettings(c: Context, key: String, model: String) {
        p(c).edit().putString("api_key", key.trim()).putString("model", model.trim()).apply()
    }

    fun tasks(c: Context): List<Task> {
        val arr = JSONArray(p(c).getString("tasks", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.getInt("id"), o.getString("goal"), o.getInt("hour"), o.getInt("minute"), o.getBoolean("daily"))
        }
    }

    private fun saveTasks(c: Context, list: List<Task>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("goal", it.goal)
                    .put("hour", it.hour).put("minute", it.minute).put("daily", it.daily)
            )
        }
        p(c).edit().putString("tasks", arr.toString()).apply()
    }

    fun addTask(c: Context, goal: String, hour: Int, minute: Int, daily: Boolean): Task {
        val t = Task((System.currentTimeMillis() % 1_000_000_000L).toInt(), goal, hour, minute, daily)
        saveTasks(c, tasks(c) + t)
        return t
    }

    fun removeTask(c: Context, id: Int) = saveTasks(c, tasks(c).filter { it.id != id })
    fun findTask(c: Context, id: Int) = tasks(c).firstOrNull { it.id == id }

    fun log(c: Context): String = p(c).getString("log", "") ?: ""
    fun clearLog(c: Context) = p(c).edit().putString("log", "").apply()
    @Synchronized
    fun appendLog(c: Context, line: String) {
        val all = (log(c) + line + "\n").takeLast(8000)
        p(c).edit().putString("log", all).apply()
    }
}
