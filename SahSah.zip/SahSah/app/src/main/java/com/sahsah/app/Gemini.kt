package com.sahsah.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Minimal Gemini API client (no libraries). */
object Gemini {
    fun ask(c: Context, prompt: String): String {
        val key = Store.apiKey(c)
        if (key.isBlank()) throw Exception("ما في مفتاح Gemini API، حطّه بصفحة المساعد")
        val model = Store.model(c)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val con = url.openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 20_000
        con.readTimeout = 90_000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        con.setRequestProperty("x-goog-api-key", key)

        val body = JSONObject()
            .put(
                "contents", JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                )
            )
            .put(
                "generationConfig", JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("temperature", 0.2)
            )
        con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("Gemini HTTP $code: ${text.take(300)}")

        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            if (!part.optBoolean("thought", false)) sb.append(part.optString("text"))
        }
        return sb.toString()
    }
}
