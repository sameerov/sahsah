package com.sahsah.app

import android.app.NotificationManager
import android.content.Context

/** Remembers whether the app is switched on, and the Do Not Disturb mode to restore. */
object State {
    private fun prefs(c: Context) = c.getSharedPreferences("sahsah", Context.MODE_PRIVATE)

    fun isOn(c: Context): Boolean = prefs(c).getBoolean("on", false)

    fun setOn(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("on", on).apply()
    }

    fun savePrevFilter(c: Context, filter: Int) {
        prefs(c).edit().putInt("prev_filter", filter).apply()
    }

    fun prevFilter(c: Context): Int {
        val f = prefs(c).getInt("prev_filter", NotificationManager.INTERRUPTION_FILTER_ALL)
        return if (f in 1..4) f else NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
